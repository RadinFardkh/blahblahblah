import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as saveProductFn, l as getProductFn, m as reorderTasksFn, o as Route$6 } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { a as Field, c as TextBox, n as Button, s as Screen } from "./ui-DBEYUEbV.mjs";
import { t as SortableTaskList } from "./sortable-task-list-BL-5pBqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assign-product-DIqnIVlR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssignProductRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, {
		access: ["full-access"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignProductPage, {})
	});
}
function AssignProductPage() {
	const { id } = Route$6.useSearch();
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [serial, setSerial] = (0, import_react.useState)("");
	const [productId, setProductId] = (0, import_react.useState)(id ?? null);
	const [tasks, setTasks] = (0, import_react.useState)([]);
	const [emptyName, setEmptyName] = (0, import_react.useState)(false);
	const [emptySerial, setEmptySerial] = (0, import_react.useState)(false);
	const [serialError, setSerialError] = (0, import_react.useState)();
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (id == null || Number.isNaN(id)) return;
		let cancelled = false;
		getProductFn({ data: { id } }).then((product) => {
			if (cancelled || !product) return;
			setName(product.name);
			setSerial(product.serial);
			setProductId(product.id);
			setTasks(product.tasks);
		});
		return () => {
			cancelled = true;
		};
	}, [id]);
	function validateFields() {
		const nameEmpty = name.trim().length === 0;
		const serialEmpty = serial.trim().length === 0;
		setEmptyName(nameEmpty);
		setEmptySerial(serialEmpty);
		setSerialError(void 0);
		return !nameEmpty && !serialEmpty;
	}
	async function persistProduct() {
		if (!validateFields()) return null;
		setBusy(true);
		try {
			const product = await saveProductFn({ data: {
				id: productId,
				name: name.trim(),
				serial: serial.trim()
			} });
			setProductId(product.id);
			setTasks(product.tasks);
			return product;
		} catch (error) {
			const message = error instanceof Error ? error.message : "Could not save product";
			setSerialError(message);
			return null;
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: productId ? "Edit product" : "Assign product",
		onBack: () => navigate({ to: "/home" }),
		wide: true,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-3xl justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: busy,
				onClick: async () => {
					if (await persistProduct()) navigate({ to: "/home" });
				},
				className: "min-w-28",
				children: "Save"
			})
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Product Name",
					error: emptyName,
					message: emptyName ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: name,
						error: emptyName,
						onChange: (e) => {
							setName(e.target.value);
							setEmptyName(false);
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Serial",
					error: emptySerial || Boolean(serialError),
					message: emptySerial ? "Required" : serialError,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: serial,
						error: emptySerial || Boolean(serialError),
						onChange: (e) => {
							setSerial(e.target.value);
							setEmptySerial(false);
							setSerialError(void 0);
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-[13px] font-medium",
					children: "Tasks"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableTaskList, {
					tasks,
					draggable: true,
					onOpen: (task) => {
						if (!productId) return;
						navigate({
							to: "/assign-task",
							search: {
								productId,
								taskId: task.id
							}
						});
					},
					onReorder: async (orderedIds) => {
						if (!productId) return;
						const next = await reorderTasksFn({ data: {
							productId,
							orderedIds
						} });
						if (next) setTasks(next.tasks);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					className: "mt-3",
					disabled: busy,
					onClick: async () => {
						const product = await persistProduct();
						if (!product) return;
						navigate({
							to: "/assign-task",
							search: { productId: product.id }
						});
					},
					children: "Add"
				})
			]
		})
	});
}
//#endregion
export { AssignProductRoute as component };
