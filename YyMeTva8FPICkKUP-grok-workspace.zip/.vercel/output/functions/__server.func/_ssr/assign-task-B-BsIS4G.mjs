import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Route$5, f as listUserOptionsFn, g as saveTaskFn, l as getProductFn } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { a as Field, c as TextBox, i as DropBox, n as Button, s as Screen, t as AreaBox } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assign-task-B-BsIS4G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AssignTaskRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, {
		access: ["full-access"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignTaskPage, {})
	});
}
function AssignTaskPage() {
	const { productId, taskId } = Route$5.useSearch();
	const navigate = useNavigate();
	const [name, setName] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [assigned, setAssigned] = (0, import_react.useState)("");
	const [users, setUsers] = (0, import_react.useState)([]);
	const [emptyName, setEmptyName] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)();
	(0, import_react.useEffect)(() => {
		listUserOptionsFn().then(setUsers);
	}, []);
	(0, import_react.useEffect)(() => {
		if (productId == null || taskId == null) return;
		let cancelled = false;
		getProductFn({ data: { id: productId } }).then((product) => {
			if (cancelled || !product) return;
			const task = product.tasks.find((t) => t.id === taskId);
			if (!task) return;
			setName(task.name);
			setDescription(task.description);
			setAssigned(task.assignedUsername);
		});
		return () => {
			cancelled = true;
		};
	}, [productId, taskId]);
	if (productId == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: "Task",
		onBack: () => navigate({ to: "/assign-product" }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Missing product."
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: taskId ? "Edit task" : "Add task",
		onBack: () => navigate({
			to: "/assign-product",
			search: { id: productId }
		}),
		wide: true,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-3xl justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: busy,
				className: "min-w-28",
				onClick: async () => {
					if (!name.trim()) {
						setEmptyName(true);
						return;
					}
					setBusy(true);
					setError(void 0);
					try {
						await saveTaskFn({ data: {
							productId,
							taskId: taskId ?? null,
							name: name.trim(),
							description,
							assignedUsername: assigned
						} });
						navigate({
							to: "/assign-product",
							search: { id: productId }
						});
					} catch (err) {
						setError(err instanceof Error ? err.message : "Could not save task");
					} finally {
						setBusy(false);
					}
				},
				children: "Save"
			})
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Task Name",
					error: emptyName,
					message: emptyName ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: name,
						error: emptyName,
						onChange: (e) => {
							setName(e.target.value);
							setEmptyName(false);
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Description:",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaBox, {
						value: description,
						onChange: (e) => setDescription(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Assigned user",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropBox, {
						value: assigned,
						onChange: (e) => setAssigned(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Unassigned"
						}), users.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: u.username,
							children: [
								u.previewname,
								" (",
								u.username,
								")"
							]
						}, u.username))]
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null
			]
		})
	});
}
//#endregion
export { AssignTaskRoute as component };
