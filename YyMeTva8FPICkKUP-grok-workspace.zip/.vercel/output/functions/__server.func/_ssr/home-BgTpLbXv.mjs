import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as listProductsFn, s as useShop } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { l as cn, n as Button } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/home-BgTpLbXv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomeRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {}) });
}
function HomePage() {
	const { user, logout } = useShop();
	const navigate = useNavigate();
	const [products, setProducts] = (0, import_react.useState)(null);
	const isManager = user?.access === "full-access";
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		listProductsFn().then((rows) => {
			if (!cancelled) setProducts(rows);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid shrink-0 grid-cols-2 gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					disabled: !isManager,
					onClick: () => navigate({ to: "/assign-product" }),
					className: "h-12",
					children: "Assign product"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					disabled: !isManager,
					onClick: () => navigate({ to: "/users" }),
					className: "h-12",
					children: "Configure users"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-4 mb-4 flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg border border-border bg-panel",
				children: products == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-4 text-sm text-muted",
					children: "Loading products…"
				}) : products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "p-6 text-sm text-muted",
					children: "No products yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex-1 overflow-y-auto",
					children: products.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: cn(index > 0 && "border-t border-border"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => navigate({
								to: "/product/$id",
								params: { id: String(product.id) }
							}),
							className: "flex w-full flex-col items-start gap-0.5 px-4 py-3.5 text-left hover:bg-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[15px] font-medium",
								children: product.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted",
								children: product.serial
							})]
						})
					}, product.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "flex shrink-0 items-center justify-between gap-3 border-t border-border bg-panel px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted",
					children: ["Status: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: user?.access
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: user?.previewname
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: async () => {
							await logout();
							navigate({ to: "/" });
						},
						className: "text-xs text-muted underline-offset-2 hover:text-fg hover:underline",
						children: "Log out"
					})]
				})]
			})
		]
	});
}
//#endregion
export { HomeRoute as component };
