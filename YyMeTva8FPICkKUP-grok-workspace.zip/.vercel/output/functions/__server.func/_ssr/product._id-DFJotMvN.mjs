import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as canOpenTaskFn, l as getProductFn, r as Route$1, s as useShop } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { n as Button, o as Popup, s as Screen } from "./ui-DBEYUEbV.mjs";
import { t as SortableTaskList } from "./sortable-task-list-BL-5pBqP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id-DFJotMvN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductPage, {}) });
}
function ProductPage() {
	const { id } = Route$1.useParams();
	const productId = Number(id);
	const navigate = useNavigate();
	const { user } = useShop();
	const [product, setProduct] = (0, import_react.useState)(null);
	const [warning, setWarning] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		getProductFn({ data: { id: productId } }).then(setProduct);
	}, [productId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: "Product",
		onBack: () => navigate({ to: "/home" }),
		wide: true,
		children: [!product ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col gap-4 pt-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-medium text-muted",
					children: "Product Name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-lg font-semibold",
					children: product.name
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-medium text-muted",
					children: "Serial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-mono text-[15px]",
					children: product.serial
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-[13px] font-medium",
					children: "Tasks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableTaskList, {
					tasks: product.tasks,
					showIndex: true,
					colorByStatus: true,
					onOpen: async (task) => {
						if (!(await canOpenTaskFn({ data: { taskId: task.id } })).ok) {
							setWarning(true);
							return;
						}
						navigate({
							to: "/product/$id/task/$taskId",
							params: {
								id: String(product.id),
								taskId: String(task.id)
							}
						});
					}
				})] }),
				user?.access === "full-access" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => navigate({
						to: "/assign-product",
						search: { id: product.id }
					}),
					children: "Edit product"
				}) : null
			]
		}), warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popup, {
			title: "Please finish the previous tasks",
			onClose: () => setWarning(false)
		}) : null]
	});
}
//#endregion
export { ProductRoute as component };
