import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as saveTaskStatusFn, l as getProductFn, n as Route, s as useShop } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { a as Field, n as Button, r as CheckPair, s as Screen, t as AreaBox } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product._id.task._taskId-BY1GWEPZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TaskStatusRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskStatusPage, {}) });
}
function TaskStatusPage() {
	const { id, taskId } = Route.useParams();
	const productId = Number(id);
	const numericTaskId = Number(taskId);
	const navigate = useNavigate();
	const { user } = useShop();
	const [task, setTask] = (0, import_react.useState)(null);
	const [assignedLabel, setAssignedLabel] = (0, import_react.useState)("");
	const [finished, setFinished] = (0, import_react.useState)(false);
	const [completion, setCompletion] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)();
	const canEdit = user?.access === "full-access" || user?.access === "editor";
	(0, import_react.useEffect)(() => {
		getProductFn({ data: { id: productId } }).then((product) => {
			const found = product?.tasks.find((t) => t.id === numericTaskId);
			if (!found) return;
			setTask(found);
			setFinished(found.finished);
			setCompletion(found.completionData);
			setAssignedLabel(found.assignedUsername || "Unassigned");
		});
	}, [productId, numericTaskId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: "Task",
		onBack: () => navigate({
			to: "/product/$id",
			params: { id: String(productId) }
		}),
		wide: true,
		footer: canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-3xl justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: busy,
				className: "min-w-28",
				onClick: async () => {
					setBusy(true);
					setError(void 0);
					try {
						await saveTaskStatusFn({ data: {
							taskId: numericTaskId,
							finished,
							completionData: completion
						} });
						navigate({
							to: "/product/$id",
							params: { id: String(productId) }
						});
					} catch (err) {
						setError(err instanceof Error ? err.message : "Could not save");
					} finally {
						setBusy(false);
					}
				},
				children: "Save"
			})
		}) : null,
		children: !task ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Loading…"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col gap-5 pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-medium text-muted",
					children: "Task name"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-lg font-semibold",
					children: task.name
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[13px] font-medium text-muted",
					children: "Assigned to"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[15px]",
					children: assignedLabel
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-[13px] font-medium",
					children: "Status"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckPair, {
					finished,
					onChange: setFinished,
					disabled: !canEdit
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Completion Data",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AreaBox, {
						value: completion,
						onChange: (e) => setCompletion(e.target.value),
						disabled: !canEdit,
						placeholder: "Optional notes"
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null
			]
		})
	});
}
//#endregion
export { TaskStatusRoute as component };
