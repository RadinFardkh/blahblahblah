import { _ as Navigate, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useShop } from "./router-C8elIkm7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/require-shop-BI-Y5O-N.js
var import_jsx_runtime = require_jsx_runtime();
function RequireShop({ children, access }) {
	const { user, ready } = useShop();
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh items-center justify-center bg-bg text-sm text-muted",
		children: "Loading…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	if (access && !access.includes(user.access)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/home" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
//#endregion
export { RequireShop as t };
