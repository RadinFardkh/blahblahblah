import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { a as shopSession, i as shopAuth, n as clearStoredToken, r as setStoredToken, t as ACCESS_LEVELS } from "./shop-types-BD01FDB7.mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-C8elIkm7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asString(value, name) {
	if (typeof value !== "string") throw new Error(`${name} is required`);
	return value;
}
function asNumber(value, name) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
	throw new Error(`${name} is required`);
}
function asAccess(value) {
	const v = asString(value, "access");
	if (!ACCESS_LEVELS.includes(v)) throw new Error("Access must be full-access, editor, or viewer");
	return v;
}
function asObject(data) {
	if (!data || typeof data !== "object") throw new Error("Invalid payload");
	return data;
}
var loginFn = createServerFn({ method: "POST" }).validator((data) => {
	const d = asObject(data);
	return {
		username: asString(d.username, "username"),
		password: asString(d.password, "password")
	};
}).handler(createSsrRpc("36dcd89e5074dab49e43ac1a982e890aabdba39e4d7239ad1d12b1d65d0610bc"));
var logoutFn = createServerFn({ method: "POST" }).middleware([shopSession]).handler(createSsrRpc("e4787547a6e8cf2c277b70b3f71a5e4fa74b719b8ee83eb456bb8513139c3eeb"));
var getMeFn = createServerFn({ method: "GET" }).middleware([shopSession]).handler(createSsrRpc("11ae059e65cccea84aec46de32976bda63efd4adccb6c956cc44b549a60d0de4"));
var listProductsFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(createSsrRpc("27df98f8b8986a6898b069618e4e52daf3154c9f2b893d5bca50837da805df8a"));
var getProductFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ id: asNumber(asObject(data).id, "id") })).handler(createSsrRpc("f529a28cdf2d65b6ff4f559a94298a6ee07af8d59a182e044f4ca8b1b3fcff5e"));
var saveProductFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
		name: asString(d.name, "name").trim(),
		serial: asString(d.serial, "serial").trim()
	};
}).handler(createSsrRpc("9aa35c4991643bdf68740506cacccbfb4c504d50478585a9e0a884eef798a4a1"));
var saveTaskFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		productId: asNumber(d.productId, "productId"),
		taskId: d.taskId == null || d.taskId === "" ? null : asNumber(d.taskId, "taskId"),
		name: asString(d.name, "name").trim(),
		description: asString(d.description, "description"),
		assignedUsername: asString(d.assignedUsername, "assignedUsername")
	};
}).handler(createSsrRpc("23b09ffa873391bd819800fd784c6a037a255656c10bc8c10edf2cf2b2a151b8"));
var reorderTasksFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	const orderedIds = d.orderedIds;
	if (!Array.isArray(orderedIds) || orderedIds.some((id) => typeof id !== "number")) throw new Error("orderedIds is required");
	return {
		productId: asNumber(d.productId, "productId"),
		orderedIds
	};
}).handler(createSsrRpc("0ddf61a7f8328f60e074ec0ba70c13f7728e11de558287a50395268e23e08c44"));
var canOpenTaskFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ taskId: asNumber(asObject(data).taskId, "taskId") })).handler(createSsrRpc("db7e22fd10c84939a7cf2190b2888114f1e221163c6238e0897076a424f374ef"));
var saveTaskStatusFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		taskId: asNumber(d.taskId, "taskId"),
		finished: Boolean(d.finished),
		completionData: asString(d.completionData, "completionData")
	};
}).handler(createSsrRpc("07da05643361d8bb20a3e728da261835c240545d16338f58cee6b0d04f3a3172"));
var listUsersFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(createSsrRpc("4437c0cddf6bf09467e01a026c0de3370a9e562cc6569c4341056b4b2ebb9c3e"));
var listUserOptionsFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(createSsrRpc("763d6365d05cb26153c8cb4e40577c906260331489592ee9d11732f99158ed4a"));
var getUserFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ id: asNumber(asObject(data).id, "id") })).handler(createSsrRpc("64113223067f84828332d95ad7f885f95de7ac8f827e85abf3a17d0b3fb1769c"));
var saveUserFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
		previewname: asString(d.previewname, "previewname").trim(),
		username: asString(d.username, "username").trim(),
		password: asString(d.password, "password"),
		access: asAccess(d.access)
	};
}).handler(createSsrRpc("160d2a33b16d69356e3cded169f8b8d9888536648e5eb3981b855f860d0bc1d3"));
var ShopContext = (0, import_react.createContext)(null);
function ShopProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getMeFn().then((next) => {
			if (!cancelled) setUser(next);
		}).catch(() => {
			if (!cancelled) setUser(null);
		}).finally(() => {
			if (!cancelled) setReady(true);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		user,
		ready,
		login: async (username, password) => {
			const result = await loginFn({ data: {
				username,
				password
			} });
			if (!result.ok) return false;
			setStoredToken(result.token);
			setUser(result.user);
			return true;
		},
		logout: async () => {
			try {
				await logoutFn();
			} catch {}
			clearStoredToken();
			setUser(null);
		}
	}), [user, ready]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopContext.Provider, {
		value,
		children
	});
}
function useShop() {
	const ctx = (0, import_react.useContext)(ShopContext);
	if (!ctx) throw new Error("useShop must be used inside ShopProvider");
	return ctx;
}
var styles_default = "/assets/styles-cmzZEBwQ.css";
var APP_NAME = "ForgeDesk";
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#243447"
			},
			{
				name: "description",
				content: "Local product and task tracking for a small shop floor."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$7 = () => import("./routes-CtBIUrmz.mjs");
var Route$7 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./assign-product-DIqnIVlR.mjs");
var Route$6 = createFileRoute("/assign-product")({
	validateSearch: (s) => ({ id: typeof s.id === "number" ? s.id : typeof s.id === "string" && s.id ? Number(s.id) : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./assign-task-B-BsIS4G.mjs");
var Route$5 = createFileRoute("/assign-task")({
	validateSearch: (s) => ({
		productId: typeof s.productId === "number" ? s.productId : typeof s.productId === "string" && s.productId ? Number(s.productId) : void 0,
		taskId: typeof s.taskId === "number" ? s.taskId : typeof s.taskId === "string" && s.taskId ? Number(s.taskId) : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./home-BgTpLbXv.mjs");
var Route$4 = createFileRoute("/home")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./user-form-Cs4MAiQa.mjs");
var Route$3 = createFileRoute("/user-form")({
	validateSearch: (s) => ({ id: typeof s.id === "number" ? s.id : typeof s.id === "string" && s.id ? Number(s.id) : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./users-DGiXEMMR.mjs");
var Route$2 = createFileRoute("/users")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./product._id-DFJotMvN.mjs");
var Route$1 = createFileRoute("/product/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./product._id.task._taskId-BY1GWEPZ.mjs");
var Route = createFileRoute("/product/$id/task/$taskId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$7.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$8
});
var AssignProductRoute = Route$6.update({
	id: "/assign-product",
	path: "/assign-product",
	getParentRoute: () => Route$8
});
var AssignTaskRoute = Route$5.update({
	id: "/assign-task",
	path: "/assign-task",
	getParentRoute: () => Route$8
});
var HomeRoute = Route$4.update({
	id: "/home",
	path: "/home",
	getParentRoute: () => Route$8
});
var UserFormRoute = Route$3.update({
	id: "/user-form",
	path: "/user-form",
	getParentRoute: () => Route$8
});
var UsersRoute = Route$2.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => Route$8
});
var ProductIdRoute = Route$1.update({
	id: "/product/$id",
	path: "/product/$id",
	getParentRoute: () => Route$8
});
var ProductIdRouteChildren = { ProductIdTaskTaskIdRoute: Route.update({
	id: "/task/$taskId",
	path: "/task/$taskId",
	getParentRoute: () => ProductIdRoute
}) };
var rootRouteChildren = {
	IndexRoute,
	AssignProductRoute,
	AssignTaskRoute,
	HomeRoute,
	UserFormRoute,
	UsersRoute,
	ProductIdRoute: ProductIdRoute._addFileChildren(ProductIdRouteChildren)
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { saveTaskStatusFn as _, Route$5 as a, canOpenTaskFn as c, listProductsFn as d, listUserOptionsFn as f, saveTaskFn as g, saveProductFn as h, Route$3 as i, getProductFn as l, reorderTasksFn as m, Route as n, Route$6 as o, listUsersFn as p, Route$1 as r, useShop as s, router_exports as t, getUserFn as u, saveUserFn as v };
