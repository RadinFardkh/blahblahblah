import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as useShop } from "./router-C8elIkm7.mjs";
import { a as Field, c as TextBox, n as Button } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CtBIUrmz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { user, ready, login } = useShop();
	const navigate = useNavigate();
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [emptyUser, setEmptyUser] = (0, import_react.useState)(false);
	const [emptyPass, setEmptyPass] = (0, import_react.useState)(false);
	const [incorrect, setIncorrect] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (ready && user) navigate({ to: "/home" });
	}, [
		ready,
		user,
		navigate
	]);
	async function onSubmit(event) {
		event.preventDefault();
		const userEmpty = username.trim().length === 0;
		const passEmpty = password.length === 0;
		setEmptyUser(userEmpty);
		setEmptyPass(passEmpty);
		setIncorrect(false);
		if (userEmpty || passEmpty) return;
		setBusy(true);
		try {
			if (!await login(username.trim(), password)) {
				setIncorrect(true);
				return;
			}
			navigate({ to: "/home" });
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "flex flex-1 flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-1 flex-col items-center justify-center px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-[220px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Username:",
						error: emptyUser || incorrect,
						message: incorrect ? "Incorrect Username/Password" : void 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
							name: "username",
							autoComplete: "username",
							value: username,
							error: emptyUser || incorrect,
							onChange: (e) => {
								setUsername(e.target.value);
								setEmptyUser(false);
								setIncorrect(false);
							}
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Password:",
						error: emptyPass || incorrect,
						message: incorrect ? "Incorrect Username/Password" : void 0,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
							name: "password",
							type: "password",
							autoComplete: "current-password",
							value: password,
							error: emptyPass || incorrect,
							onChange: (e) => {
								setPassword(e.target.value);
								setEmptyPass(false);
								setIncorrect(false);
							}
						})
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-3 pb-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: busy,
					className: "min-w-32",
					children: busy ? "Checking…" : "Login"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xs text-center text-[11px] leading-4 text-subtle",
					children: "Local demo: manager / manager · editor / editor · viewer / viewer"
				})]
			})]
		})
	});
}
//#endregion
export { LoginPage as component };
