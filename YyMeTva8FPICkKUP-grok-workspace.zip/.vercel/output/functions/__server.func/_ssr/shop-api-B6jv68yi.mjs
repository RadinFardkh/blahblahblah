import { n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { a as shopSession, i as shopAuth, t as ACCESS_LEVELS } from "./shop-types-BD01FDB7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-api-B6jv68yi.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function asString(value, name) {
	if (typeof value !== "string") throw new Error(`${name} is required`);
	return value;
}
function asNumber(value, name) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
	throw new Error(`${name} is required`);
}
function asAccess(value) {
	const v = asString(value, "access");
	if (!ACCESS_LEVELS.includes(v)) throw new Error("Access must be full-access, editor, or viewer");
	return v;
}
function asObject(data) {
	if (!data || typeof data !== "object") throw new Error("Invalid payload");
	return data;
}
var loginFn_createServerFn_handler = createServerRpc({
	id: "36dcd89e5074dab49e43ac1a982e890aabdba39e4d7239ad1d12b1d65d0610bc",
	name: "loginFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => loginFn.__executeServer(opts));
var loginFn = createServerFn({ method: "POST" }).validator((data) => {
	const d = asObject(data);
	return {
		username: asString(d.username, "username"),
		password: asString(d.password, "password")
	};
}).handler(loginFn_createServerFn_handler, async ({ data }) => {
	const result = await (await import("./shop-db.server-D3pFLOIO.mjs")).loginWithPassword(data.username, data.password);
	if (!result) return { ok: false };
	return {
		ok: true,
		token: result.token,
		user: result.user
	};
});
var logoutFn_createServerFn_handler = createServerRpc({
	id: "e4787547a6e8cf2c277b70b3f71a5e4fa74b719b8ee83eb456bb8513139c3eeb",
	name: "logoutFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => logoutFn.__executeServer(opts));
var logoutFn = createServerFn({ method: "POST" }).middleware([shopSession]).handler(logoutFn_createServerFn_handler, async ({ context }) => {
	await (await import("./shop-db.server-D3pFLOIO.mjs")).logoutToken(context.shopToken);
	return { ok: true };
});
var getMeFn_createServerFn_handler = createServerRpc({
	id: "11ae059e65cccea84aec46de32976bda63efd4adccb6c956cc44b549a60d0de4",
	name: "getMeFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => getMeFn.__executeServer(opts));
var getMeFn = createServerFn({ method: "GET" }).middleware([shopSession]).handler(getMeFn_createServerFn_handler, async ({ context }) => {
	return context.shopUser ?? null;
});
var listProductsFn_createServerFn_handler = createServerRpc({
	id: "27df98f8b8986a6898b069618e4e52daf3154c9f2b893d5bca50837da805df8a",
	name: "listProductsFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => listProductsFn.__executeServer(opts));
var listProductsFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(listProductsFn_createServerFn_handler, async () => {
	return (await import("./shop-db.server-D3pFLOIO.mjs")).listProducts();
});
var getProductFn_createServerFn_handler = createServerRpc({
	id: "f529a28cdf2d65b6ff4f559a94298a6ee07af8d59a182e044f4ca8b1b3fcff5e",
	name: "getProductFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => getProductFn.__executeServer(opts));
var getProductFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ id: asNumber(asObject(data).id, "id") })).handler(getProductFn_createServerFn_handler, async ({ data }) => {
	return (await import("./shop-db.server-D3pFLOIO.mjs")).getProduct(data.id);
});
var saveProductFn_createServerFn_handler = createServerRpc({
	id: "9aa35c4991643bdf68740506cacccbfb4c504d50478585a9e0a884eef798a4a1",
	name: "saveProductFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => saveProductFn.__executeServer(opts));
var saveProductFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
		name: asString(d.name, "name").trim(),
		serial: asString(d.serial, "serial").trim()
	};
}).handler(saveProductFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	if (!data.name) throw new Error("Product name is required");
	if (!data.serial) throw new Error("Serial is required");
	if (data.id == null) return db.createProduct(data.name, data.serial);
	return db.updateProduct(data.id, data.name, data.serial);
});
var saveTaskFn_createServerFn_handler = createServerRpc({
	id: "23b09ffa873391bd819800fd784c6a037a255656c10bc8c10edf2cf2b2a151b8",
	name: "saveTaskFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => saveTaskFn.__executeServer(opts));
var saveTaskFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		productId: asNumber(d.productId, "productId"),
		taskId: d.taskId == null || d.taskId === "" ? null : asNumber(d.taskId, "taskId"),
		name: asString(d.name, "name").trim(),
		description: asString(d.description, "description"),
		assignedUsername: asString(d.assignedUsername, "assignedUsername")
	};
}).handler(saveTaskFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	if (!data.name) throw new Error("Task name is required");
	if (data.taskId == null) return db.createTask({
		productId: data.productId,
		name: data.name,
		description: data.description,
		assignedUsername: data.assignedUsername
	});
	return db.updateTask({
		taskId: data.taskId,
		name: data.name,
		description: data.description,
		assignedUsername: data.assignedUsername
	});
});
var reorderTasksFn_createServerFn_handler = createServerRpc({
	id: "0ddf61a7f8328f60e074ec0ba70c13f7728e11de558287a50395268e23e08c44",
	name: "reorderTasksFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => reorderTasksFn.__executeServer(opts));
var reorderTasksFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	const orderedIds = d.orderedIds;
	if (!Array.isArray(orderedIds) || orderedIds.some((id) => typeof id !== "number")) throw new Error("orderedIds is required");
	return {
		productId: asNumber(d.productId, "productId"),
		orderedIds
	};
}).handler(reorderTasksFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	await db.reorderTasks(data.productId, data.orderedIds);
	return db.getProduct(data.productId);
});
var canOpenTaskFn_createServerFn_handler = createServerRpc({
	id: "db7e22fd10c84939a7cf2190b2888114f1e221163c6238e0897076a424f374ef",
	name: "canOpenTaskFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => canOpenTaskFn.__executeServer(opts));
var canOpenTaskFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ taskId: asNumber(asObject(data).taskId, "taskId") })).handler(canOpenTaskFn_createServerFn_handler, async ({ data }) => {
	return { ok: await (await import("./shop-db.server-D3pFLOIO.mjs")).previousTasksFinished(data.taskId) };
});
var saveTaskStatusFn_createServerFn_handler = createServerRpc({
	id: "07da05643361d8bb20a3e728da261835c240545d16338f58cee6b0d04f3a3172",
	name: "saveTaskStatusFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => saveTaskStatusFn.__executeServer(opts));
var saveTaskStatusFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		taskId: asNumber(d.taskId, "taskId"),
		finished: Boolean(d.finished),
		completionData: asString(d.completionData, "completionData")
	};
}).handler(saveTaskStatusFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireEditor(context.shopUser);
	return db.updateTaskStatus(data);
});
var listUsersFn_createServerFn_handler = createServerRpc({
	id: "4437c0cddf6bf09467e01a026c0de3370a9e562cc6569c4341056b4b2ebb9c3e",
	name: "listUsersFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => listUsersFn.__executeServer(opts));
var listUsersFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(listUsersFn_createServerFn_handler, async ({ context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	return db.listUsers();
});
var listUserOptionsFn_createServerFn_handler = createServerRpc({
	id: "763d6365d05cb26153c8cb4e40577c906260331489592ee9d11732f99158ed4a",
	name: "listUserOptionsFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => listUserOptionsFn.__executeServer(opts));
var listUserOptionsFn = createServerFn({ method: "GET" }).middleware([shopAuth]).handler(listUserOptionsFn_createServerFn_handler, async () => {
	return (await (await import("./shop-db.server-D3pFLOIO.mjs")).listUsers()).map((u) => ({
		username: u.username,
		previewname: u.previewname
	}));
});
var getUserFn_createServerFn_handler = createServerRpc({
	id: "64113223067f84828332d95ad7f885f95de7ac8f827e85abf3a17d0b3fb1769c",
	name: "getUserFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => getUserFn.__executeServer(opts));
var getUserFn = createServerFn({ method: "GET" }).middleware([shopAuth]).validator((data) => ({ id: asNumber(asObject(data).id, "id") })).handler(getUserFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	return db.getUser(data.id);
});
var saveUserFn_createServerFn_handler = createServerRpc({
	id: "160d2a33b16d69356e3cded169f8b8d9888536648e5eb3981b855f860d0bc1d3",
	name: "saveUserFn",
	filename: "src/lib/shop-api.ts"
}, (opts) => saveUserFn.__executeServer(opts));
var saveUserFn = createServerFn({ method: "POST" }).middleware([shopAuth]).validator((data) => {
	const d = asObject(data);
	return {
		id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
		previewname: asString(d.previewname, "previewname").trim(),
		username: asString(d.username, "username").trim(),
		password: asString(d.password, "password"),
		access: asAccess(d.access)
	};
}).handler(saveUserFn_createServerFn_handler, async ({ data, context }) => {
	const db = await import("./shop-db.server-D3pFLOIO.mjs");
	db.requireFullAccess(context.shopUser);
	if (!data.previewname) throw new Error("Preview name is required");
	if (!data.username) throw new Error("Username is required");
	if (!data.password) throw new Error("Password is required");
	if (data.id == null) return db.createUser({
		previewname: data.previewname,
		username: data.username,
		password: data.password,
		access: data.access
	});
	return db.updateUser(data.id, {
		previewname: data.previewname,
		username: data.username,
		password: data.password,
		access: data.access
	}, context.shopUser.id);
});
//#endregion
export { canOpenTaskFn_createServerFn_handler, getMeFn_createServerFn_handler, getProductFn_createServerFn_handler, getUserFn_createServerFn_handler, listProductsFn_createServerFn_handler, listUserOptionsFn_createServerFn_handler, listUsersFn_createServerFn_handler, loginFn_createServerFn_handler, logoutFn_createServerFn_handler, reorderTasksFn_createServerFn_handler, saveProductFn_createServerFn_handler, saveTaskFn_createServerFn_handler, saveTaskStatusFn_createServerFn_handler, saveUserFn_createServerFn_handler };
