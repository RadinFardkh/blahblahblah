import { t as ACCESS_LEVELS } from "./shop-types-BD01FDB7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-db.server-D3pFLOIO.js
var _0002_shop_default = "-- ForgeDesk local data (users.db / products.db / status.db equivalents)\n-- Shared company tables — not scoped to a Grok identity.\n\ncreate table if not exists shop_users (\n  id           serial primary key,\n  previewname  text not null,\n  username     text not null unique,\n  password     text not null,\n  access       text not null check (access in ('full-access', 'editor', 'viewer'))\n);\n\ncreate table if not exists shop_sessions (\n  token      text primary key,\n  user_id    integer not null references shop_users(id) on delete cascade,\n  created_at timestamptz not null default now()\n);\n\ncreate table if not exists shop_products (\n  id         serial primary key,\n  name       text not null,\n  serial     text not null unique\n);\n\ncreate table if not exists shop_product_tasks (\n  id                 serial primary key,\n  product_id         integer not null references shop_products(id) on delete cascade,\n  task_index         integer not null,\n  name               text not null,\n  description        text not null default '',\n  assigned_username  text not null default '',\n  unique (product_id, task_index)\n);\n\ncreate table if not exists shop_task_status (\n  id                serial primary key,\n  product_id        integer not null references shop_products(id) on delete cascade,\n  task_id           integer not null references shop_product_tasks(id) on delete cascade,\n  finished          boolean not null default false,\n  completion_data   text not null default '',\n  unique (product_id, task_id)\n);\n\ncreate index if not exists shop_sessions_user_id_idx on shop_sessions (user_id);\ncreate index if not exists shop_product_tasks_product_idx on shop_product_tasks (product_id, task_index);\ncreate index if not exists shop_task_status_product_idx on shop_task_status (product_id);\n\n-- Seed accounts so the login screen is usable immediately.\ninsert into shop_users (previewname, username, password, access)\nselect 'Alex Chen', 'manager', 'manager', 'full-access'\nwhere not exists (select 1 from shop_users where username = 'manager');\n\ninsert into shop_users (previewname, username, password, access)\nselect 'Sam Ortiz', 'editor', 'editor', 'editor'\nwhere not exists (select 1 from shop_users where username = 'editor');\n\ninsert into shop_users (previewname, username, password, access)\nselect 'Riley Cho', 'viewer', 'viewer', 'viewer'\nwhere not exists (select 1 from shop_users where username = 'viewer');\n\ninsert into shop_products (name, serial)\nselect 'Hydraulic Press HP-12', 'HP12-0042'\nwhere not exists (select 1 from shop_products where serial = 'HP12-0042');\n\ninsert into shop_product_tasks (product_id, task_index, name, description, assigned_username)\nselect p.id, 1, 'Incoming inspection',\n       'Check crate, serial plate, and housing for damage or missing parts.',\n       'editor'\nfrom shop_products p\nwhere p.serial = 'HP12-0042'\n  and not exists (\n    select 1 from shop_product_tasks t\n    where t.product_id = p.id and t.task_index = 1\n  );\n\ninsert into shop_product_tasks (product_id, task_index, name, description, assigned_username)\nselect p.id, 2, 'Assembly check',\n       'Verify ram alignment, hoses, and electrical harness before power-on.',\n       'editor'\nfrom shop_products p\nwhere p.serial = 'HP12-0042'\n  and not exists (\n    select 1 from shop_product_tasks t\n    where t.product_id = p.id and t.task_index = 2\n  );\n\ninsert into shop_product_tasks (product_id, task_index, name, description, assigned_username)\nselect p.id, 3, 'Final QA',\n       'Run pressure cycle, record results, and sign off for shipping.',\n       'manager'\nfrom shop_products p\nwhere p.serial = 'HP12-0042'\n  and not exists (\n    select 1 from shop_product_tasks t\n    where t.product_id = p.id and t.task_index = 3\n  );\n\n-- Status rows for every template task (unfinished by default).\ninsert into shop_task_status (product_id, task_id, finished, completion_data)\nselect t.product_id, t.id, false, ''\nfrom shop_product_tasks t\nwhere not exists (\n  select 1 from shop_task_status s where s.task_id = t.id\n);\n\n-- Mark the first sample task finished so sequential flow is visible.\nupdate shop_task_status s\nset finished = true,\n    completion_data = 'Crate intact. Serial plate matches HP12-0042.'\nfrom shop_product_tasks t\njoin shop_products p on p.id = t.product_id\nwhere s.task_id = t.id\n  and p.serial = 'HP12-0042'\n  and t.task_index = 1;\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({ "/migrations/0002_shop.sql": _0002_shop_default });
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function asAccess(value) {
	if (ACCESS_LEVELS.includes(value)) return value;
	return "viewer";
}
function asBool(value) {
	return value === true || value === "t" || value === "true" || value === 1;
}
function toUser(row) {
	return {
		id: row.id,
		previewname: row.previewname,
		username: row.username,
		access: asAccess(row.access)
	};
}
function toUserRecord(row) {
	return {
		...toUser(row),
		password: row.password
	};
}
async function loadUserByToken(token) {
	const rows = await (await getSql())`
    select u.id, u.previewname, u.username, u.password, u.access
    from shop_sessions s
    join shop_users u on u.id = s.user_id
    where s.token = ${token}
    limit 1
  `;
	return rows[0] ? toUser(rows[0]) : null;
}
async function loginWithPassword(username, password) {
	const sql = await getSql();
	const row = (await sql`
    select id, previewname, username, password, access
    from shop_users
    where username = ${username}
    limit 1
  `)[0];
	if (!row || row.password !== password) return null;
	const token = crypto.randomUUID();
	await sql`insert into shop_sessions (token, user_id) values (${token}, ${row.id})`;
	return {
		token,
		user: toUser(row)
	};
}
async function logoutToken(token) {
	if (!token) return;
	await (await getSql())`delete from shop_sessions where token = ${token}`;
}
async function listUsers() {
	return (await (await getSql())`
    select id, previewname, username, password, access
    from shop_users
    order by id
  `).map(toUserRecord);
}
async function getUser(id) {
	const rows = await (await getSql())`
    select id, previewname, username, password, access
    from shop_users where id = ${id} limit 1
  `;
	return rows[0] ? toUserRecord(rows[0]) : null;
}
async function createUser(input) {
	const sql = await getSql();
	if (((await sql`
    select count(*)::int as n from shop_users where username = ${input.username}
  `)[0]?.n ?? 0) > 0) throw new Error("Username already exists");
	return toUserRecord((await sql`
    insert into shop_users (previewname, username, password, access)
    values (${input.previewname}, ${input.username}, ${input.password}, ${input.access})
    returning id, previewname, username, password, access
  `)[0]);
}
async function updateUser(id, input, actorId) {
	const sql = await getSql();
	const current = await getUser(id);
	if (!current) throw new Error("User not found");
	if (((await sql`
    select count(*)::int as n from shop_users
    where username = ${input.username} and id <> ${id}
  `)[0]?.n ?? 0) > 0) throw new Error("Username already exists");
	if (current.access === "full-access" && input.access !== "full-access") {
		if (((await sql`
      select count(*)::int as n from shop_users
      where access = 'full-access' and id <> ${id}
    `)[0]?.n ?? 0) < 1) throw new Error("At least one full-access user is required");
		if (actorId === id) throw new Error("You cannot remove your own full-access role");
	}
	return toUserRecord((await sql`
    update shop_users
    set previewname = ${input.previewname},
        username = ${input.username},
        password = ${input.password},
        access = ${input.access}
    where id = ${id}
    returning id, previewname, username, password, access
  `)[0]);
}
async function listProducts() {
	return (await getSql())`
    select id, name, serial from shop_products order by id
  `;
}
function toTask(row) {
	return {
		id: row.id,
		productId: row.product_id,
		index: row.task_index,
		name: row.name,
		description: row.description,
		assignedUsername: row.assigned_username,
		finished: asBool(row.finished),
		completionData: row.completion_data ?? ""
	};
}
async function getProduct(id) {
	const sql = await getSql();
	const product = (await sql`
    select id, name, serial from shop_products where id = ${id} limit 1
  `)[0];
	if (!product) return null;
	const tasks = await sql`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.product_id = ${id}
    order by t.task_index
  `;
	return {
		...product,
		tasks: tasks.map(toTask)
	};
}
async function ensureStatusRow(productId, taskId) {
	await (await getSql())`
    insert into shop_task_status (product_id, task_id, finished, completion_data)
    values (${productId}, ${taskId}, false, '')
    on conflict (product_id, task_id) do nothing
  `;
}
async function createProduct(name, serial) {
	const sql = await getSql();
	if (((await sql`
    select count(*)::int as n from shop_products where serial = ${serial}
  `)[0]?.n ?? 0) > 0) throw new Error("Serial already exists");
	return {
		...(await sql`
    insert into shop_products (name, serial)
    values (${name}, ${serial})
    returning id, name, serial
  `)[0],
		tasks: []
	};
}
async function updateProduct(id, name, serial) {
	const sql = await getSql();
	if (((await sql`
    select count(*)::int as n from shop_products
    where serial = ${serial} and id <> ${id}
  `)[0]?.n ?? 0) > 0) throw new Error("Serial already exists");
	await sql`
    update shop_products set name = ${name}, serial = ${serial} where id = ${id}
  `;
	const product = await getProduct(id);
	if (!product) throw new Error("Product not found");
	return product;
}
async function createTask(input) {
	const sql = await getSql();
	const nextIndex = ((await sql`
    select max(task_index)::int as m from shop_product_tasks where product_id = ${input.productId}
  `)[0]?.m ?? 0) + 1;
	const taskId = (await sql`
    insert into shop_product_tasks (product_id, task_index, name, description, assigned_username)
    values (${input.productId}, ${nextIndex}, ${input.name}, ${input.description}, ${input.assignedUsername})
    returning id
  `)[0].id;
	await ensureStatusRow(input.productId, taskId);
	const task = (await getProduct(input.productId))?.tasks.find((t) => t.id === taskId);
	if (!task) throw new Error("Task was not created");
	return task;
}
async function updateTask(input) {
	const sql = await getSql();
	await sql`
    update shop_product_tasks
    set name = ${input.name},
        description = ${input.description},
        assigned_username = ${input.assignedUsername}
    where id = ${input.taskId}
  `;
	const rows = await sql`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.id = ${input.taskId}
    limit 1
  `;
	if (!rows[0]) throw new Error("Task not found");
	return toTask(rows[0]);
}
async function reorderTasks(productId, orderedIds) {
	const sql = await getSql();
	for (let i = 0; i < orderedIds.length; i += 1) {
		const id = orderedIds[i];
		await sql`
      update shop_product_tasks
      set task_index = ${i + 1}
      where id = ${id} and product_id = ${productId}
    `;
	}
}
async function updateTaskStatus(input) {
	const sql = await getSql();
	const task = (await sql`
    select product_id, task_index from shop_product_tasks where id = ${input.taskId} limit 1
  `)[0];
	if (!task) throw new Error("Task not found");
	if (input.finished) {
		if (((await sql`
      select count(*)::int as n
      from shop_product_tasks t
      left join shop_task_status s on s.task_id = t.id
      where t.product_id = ${task.product_id}
        and t.task_index < ${task.task_index}
        and coalesce(s.finished, false) = false
    `)[0]?.n ?? 0) > 0) throw new Error("Please finish the previous tasks");
	}
	await ensureStatusRow(task.product_id, input.taskId);
	await sql`
    update shop_task_status
    set finished = ${input.finished},
        completion_data = ${input.completionData}
    where task_id = ${input.taskId}
  `;
	return toTask((await sql`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.id = ${input.taskId}
    limit 1
  `)[0]);
}
async function previousTasksFinished(taskId) {
	const sql = await getSql();
	const task = (await sql`
    select product_id, task_index from shop_product_tasks where id = ${taskId} limit 1
  `)[0];
	if (!task) return false;
	return ((await sql`
    select count(*)::int as n
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.product_id = ${task.product_id}
      and t.task_index < ${task.task_index}
      and coalesce(s.finished, false) = false
  `)[0]?.n ?? 0) === 0;
}
function requireFullAccess(user) {
	if (user.access !== "full-access") throw new Error("Full-access only");
}
function requireEditor(user) {
	if (user.access !== "full-access" && user.access !== "editor") throw new Error("You do not have permission to edit this");
}
//#endregion
export { createProduct, createTask, createUser, getProduct, getUser, listProducts, listUsers, loadUserByToken, loginWithPassword, logoutToken, previousTasksFinished, reorderTasks, requireEditor, requireFullAccess, updateProduct, updateTask, updateTaskStatus, updateUser };
