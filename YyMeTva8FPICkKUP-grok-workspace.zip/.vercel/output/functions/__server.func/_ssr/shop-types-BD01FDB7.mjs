import { t as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-types-BD01FDB7.js
var TOKEN_KEY = "forgedesk.token";
function getStoredToken() {
	if (typeof window === "undefined") return null;
	try {
		return window.localStorage.getItem(TOKEN_KEY);
	} catch {
		return null;
	}
}
function setStoredToken(token) {
	window.localStorage.setItem(TOKEN_KEY, token);
}
function clearStoredToken() {
	window.localStorage.removeItem(TOKEN_KEY);
}
async function resolveUser(token) {
	if (!token) return null;
	const { loadUserByToken } = await import("./shop-db.server-D3pFLOIO.mjs");
	return loadUserByToken(token);
}
/** Attaches shopUser (null if signed out) and the raw token. */
var shopSession = createMiddleware({ type: "function" }).client(async ({ next }) => {
	return next({ sendContext: { shopToken: getStoredToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const shopToken = context.shopToken;
	return next({ context: {
		shopUser: await resolveUser(shopToken),
		shopToken
	} });
});
/** Requires a signed-in shop user. */
var shopAuth = createMiddleware({ type: "function" }).client(async ({ next }) => {
	return next({ sendContext: { shopToken: getStoredToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const shopToken = context.shopToken;
	const shopUser = await resolveUser(shopToken);
	if (!shopUser) throw new Error("Not signed in");
	return next({ context: {
		shopUser,
		shopToken
	} });
});
var ACCESS_LEVELS = [
	"full-access",
	"editor",
	"viewer"
];
//#endregion
export { shopSession as a, shopAuth as i, clearStoredToken as n, setStoredToken as r, ACCESS_LEVELS as t };
