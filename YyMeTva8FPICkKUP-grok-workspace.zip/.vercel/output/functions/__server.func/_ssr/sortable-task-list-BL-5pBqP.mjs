import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as GripVertical } from "../_libs/lucide-react.mjs";
import { l as cn } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sortable-task-list-BL-5pBqP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SortableTaskList({ tasks, onOpen, onReorder, showIndex, colorByStatus, draggable }) {
	const [draggingId, setDraggingId] = (0, import_react.useState)(null);
	const [overId, setOverId] = (0, import_react.useState)(null);
	const dragIdRef = (0, import_react.useRef)(null);
	const overIdRef = (0, import_react.useRef)(null);
	if (tasks.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-32 items-center justify-center rounded-lg border border-dashed border-border bg-surface text-sm text-muted",
		children: "No tasks yet"
	});
	function finishDrag() {
		const fromId = dragIdRef.current;
		const toId = overIdRef.current;
		dragIdRef.current = null;
		overIdRef.current = null;
		setDraggingId(null);
		setOverId(null);
		if (fromId == null || toId == null || fromId === toId) return;
		const next = tasks.map((t) => t.id);
		const from = next.indexOf(fromId);
		const to = next.indexOf(toId);
		if (from < 0 || to < 0) return;
		next.splice(from, 1);
		next.splice(to, 0, fromId);
		onReorder?.(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-2",
		children: tasks.map((task) => {
			const isOver = overId === task.id && draggingId !== task.id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				"data-task-id": task.id,
				className: cn("flex items-stretch overflow-hidden rounded-md border bg-panel", isOver ? "border-primary" : "border-border", draggingId === task.id && "opacity-70"),
				children: [draggable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Drag to reorder",
					className: "flex w-10 shrink-0 touch-none cursor-grab items-center justify-center border-r border-border text-subtle active:cursor-grabbing",
					onPointerDown: (event) => {
						event.preventDefault();
						event.currentTarget.setPointerCapture(event.pointerId);
						dragIdRef.current = task.id;
						overIdRef.current = task.id;
						setDraggingId(task.id);
						setOverId(task.id);
					},
					onPointerMove: (event) => {
						if (dragIdRef.current == null) return;
						const row = document.elementFromPoint(event.clientX, event.clientY)?.closest("[data-task-id]");
						const id = row ? Number(row.dataset.taskId) : NaN;
						if (!Number.isFinite(id)) return;
						overIdRef.current = id;
						setOverId(id);
					},
					onPointerUp: finishDrag,
					onPointerCancel: finishDrag,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GripVertical, { className: "size-4" })
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onOpen(task),
					className: "flex min-h-12 flex-1 items-center px-3 py-2 text-left text-[15px]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn(colorByStatus && task.finished ? "font-medium text-success" : "text-fg"),
						children: showIndex ? `${task.index}. ${task.name}` : task.name
					})
				})]
			}, task.id);
		})
	});
}
//#endregion
export { SortableTaskList as t };
