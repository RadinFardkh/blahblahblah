import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-DBEYUEbV.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Screen({ title, onBack, footer, children, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-fg",
		children: [
			title || onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-14 shrink-0 items-center gap-3 border-b border-border bg-panel px-4",
				children: [onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onBack,
					className: "inline-flex h-9 min-w-16 items-center justify-center rounded-md border border-border bg-surface px-3 text-sm font-medium text-fg hover:bg-row",
					children: "Back"
				}) : null, title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[15px] font-semibold tracking-tight",
					children: title
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: cn("flex flex-1 flex-col overflow-auto p-4", wide ? "mx-auto w-full max-w-3xl" : ""),
				children
			}),
			footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "shrink-0 border-t border-border bg-panel px-4 py-3",
				children: footer
			}) : null
		]
	});
}
function Field({ label, error, message, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mb-1.5 text-[13px] font-medium text-fg",
				children: label
			}),
			children,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1.5 min-h-5 text-xs leading-4", error && message ? "text-muted" : "text-transparent"),
				children: message || "placeholder"
			})
		]
	});
}
var controlClass = "h-11 w-full rounded-md border bg-panel px-3 text-[15px] text-fg outline-none transition-colors placeholder:text-subtle focus:border-primary";
function TextBox({ error, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(controlClass, error ? "border-danger" : "border-border", className)
	});
}
function AreaBox({ error, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		...props,
		className: cn("min-h-24 w-full resize-y rounded-md border bg-panel px-3 py-2 text-[15px] text-fg outline-none placeholder:text-subtle focus:border-primary", error ? "border-danger" : "border-border", className)
	});
}
function DropBox({ error, className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(controlClass, error ? "border-danger" : "border-border", className),
		children
	});
}
function Button({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...props,
		className: cn("inline-flex h-11 items-center justify-center rounded-md px-4 text-sm font-semibold transition-colors", variant === "primary" && "bg-primary text-primary-fg hover:opacity-90 disabled:bg-disabled disabled:text-disabled-fg", variant === "secondary" && "border border-border bg-panel text-fg hover:bg-row disabled:bg-row disabled:text-disabled-fg", variant === "ghost" && "text-muted hover:text-fg", className)
	});
}
function Popup({ title, children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-fg/40 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-labelledby": "popup-title",
			className: "w-full max-w-sm rounded-xl border border-border bg-panel p-5 shadow-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "popup-title",
					className: "text-base font-semibold",
					children: title
				}),
				children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 text-sm text-muted",
					children
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: onClose,
						className: "min-w-24",
						children: "OK"
					})
				})
			]
		})
	});
}
function CheckPair({ finished, onChange, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-6 py-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "inline-flex min-h-11 items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "size-5 accent-success",
				checked: finished,
				disabled,
				onChange: () => onChange(true)
			}), "Finished"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "inline-flex min-h-11 items-center gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "checkbox",
				className: "size-5 accent-primary",
				checked: !finished,
				disabled,
				onChange: () => onChange(false)
			}), "Unfinished"]
		})]
	});
}
//#endregion
export { Field as a, TextBox as c, DropBox as i, cn as l, Button as n, Popup as o, CheckPair as r, Screen as s, AreaBox as t };
