import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as ACCESS_LEVELS } from "./shop-types-BD01FDB7.mjs";
import { i as Route$3, u as getUserFn, v as saveUserFn } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { a as Field, c as TextBox, i as DropBox, n as Button, s as Screen } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/user-form-Cs4MAiQa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UserFormRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, {
		access: ["full-access"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserFormPage, {})
	});
}
function UserFormPage() {
	const { id } = Route$3.useSearch();
	const navigate = useNavigate();
	const [previewname, setPreviewname] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [access, setAccess] = (0, import_react.useState)("");
	const [empty, setEmpty] = (0, import_react.useState)({
		previewname: false,
		username: false,
		password: false,
		access: false
	});
	const [error, setError] = (0, import_react.useState)();
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (id == null) return;
		getUserFn({ data: { id } }).then((user) => {
			if (!user) return;
			setPreviewname(user.previewname);
			setUsername(user.username);
			setPassword(user.password);
			setAccess(user.access);
		});
	}, [id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: id ? "Edit user" : "New User",
		onBack: () => navigate({ to: "/users" }),
		wide: true,
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex w-full max-w-3xl justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				disabled: busy,
				className: "min-w-28",
				onClick: async () => {
					const nextEmpty = {
						previewname: previewname.trim().length === 0,
						username: username.trim().length === 0,
						password: password.length === 0,
						access: access === ""
					};
					setEmpty(nextEmpty);
					setError(void 0);
					if (Object.values(nextEmpty).some(Boolean)) return;
					setBusy(true);
					try {
						await saveUserFn({ data: {
							id: id ?? null,
							previewname: previewname.trim(),
							username: username.trim(),
							password,
							access
						} });
						navigate({ to: "/users" });
					} catch (err) {
						setError(err instanceof Error ? err.message : "Could not save user");
					} finally {
						setBusy(false);
					}
				},
				children: "Save"
			})
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-col pt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Preview name",
					error: empty.previewname,
					message: empty.previewname ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: previewname,
						error: empty.previewname,
						onChange: (e) => {
							setPreviewname(e.target.value);
							setEmpty((s) => ({
								...s,
								previewname: false
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Username",
					error: empty.username,
					message: empty.username ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: username,
						error: empty.username,
						onChange: (e) => {
							setUsername(e.target.value);
							setEmpty((s) => ({
								...s,
								username: false
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Password",
					error: empty.password,
					message: empty.password ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextBox, {
						value: password,
						error: empty.password,
						onChange: (e) => {
							setPassword(e.target.value);
							setEmpty((s) => ({
								...s,
								password: false
							}));
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Access",
					error: empty.access,
					message: empty.access ? "Required" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropBox, {
						value: access,
						error: empty.access,
						onChange: (e) => {
							setAccess(e.target.value);
							setEmpty((s) => ({
								...s,
								access: false
							}));
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: id ? "" : "Select access"
						}), ACCESS_LEVELS.map((level) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: level,
							children: level
						}, level))]
					})
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null
			]
		})
	});
}
//#endregion
export { UserFormRoute as component };
