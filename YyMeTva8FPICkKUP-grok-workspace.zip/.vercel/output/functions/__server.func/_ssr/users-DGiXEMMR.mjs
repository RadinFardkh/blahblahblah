import { o as __toESM } from "../_runtime.mjs";
import { B as require_react, b as require_jsx_runtime, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { p as listUsersFn } from "./router-C8elIkm7.mjs";
import { t as RequireShop } from "./require-shop-BI-Y5O-N.mjs";
import { l as cn, n as Button, s as Screen } from "./ui-DBEYUEbV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/users-DGiXEMMR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UsersRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequireShop, {
		access: ["full-access"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersPage, {})
	});
}
function UsersPage() {
	const navigate = useNavigate();
	const [rows, setRows] = (0, import_react.useState)(null);
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		listUsersFn().then(setRows);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: "Configure users",
		onBack: () => navigate({ to: "/home" }),
		wide: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-x-auto rounded-lg border border-border bg-panel",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[28rem] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border bg-surface text-xs uppercase tracking-wide text-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2.5 font-medium",
							children: "Preview name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2.5 font-medium",
							children: "Username"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2.5 font-medium",
							children: "Access"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (rows ?? []).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					onClick: () => setSelectedId(row.id),
					onDoubleClick: () => navigate({
						to: "/user-form",
						search: { id: row.id }
					}),
					className: cn("cursor-pointer border-t border-border", selectedId === row.id ? "bg-row-active" : "hover:bg-row"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3",
							children: row.previewname
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3 font-mono text-[13px]",
							children: row.username
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-3",
							children: row.access
						})
					]
				}, row.id)) })]
			}), rows && rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-3 py-6 text-sm text-muted",
				children: "No users."
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "secondary",
				disabled: selectedId == null,
				onClick: () => {
					if (selectedId == null) return;
					navigate({
						to: "/user-form",
						search: { id: selectedId }
					});
				},
				className: "min-w-28",
				children: "Edit"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				onClick: () => navigate({ to: "/user-form" }),
				className: "min-w-28",
				children: "New User"
			})]
		})]
	});
}
//#endregion
export { UsersRoute as component };
