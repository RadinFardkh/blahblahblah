//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHc9APlg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/assign-product",
			"/assign-task",
			"/home",
			"/user-form",
			"/users",
			"/product/$id"
		],
		preloads: ["/assets/index-EvdZ2fQP.js", "/assets/shop-provider-DgoY09Aq.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-EvdZ2fQP.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BBij3BIu.js", "/assets/ui-E61OhsJF.js"]
	},
	"/assign-product": {
		filePath: "/workspace/src/routes/assign-product.tsx",
		children: void 0,
		preloads: [
			"/assets/assign-product-Cfvj0BFo.js",
			"/assets/sortable-task-list-ClBh1pBS.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/assign-task": {
		filePath: "/workspace/src/routes/assign-task.tsx",
		children: void 0,
		preloads: [
			"/assets/assign-task-pWn1nSI6.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/home": {
		filePath: "/workspace/src/routes/home.tsx",
		children: void 0,
		preloads: [
			"/assets/home-B0FNTcSx.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/user-form": {
		filePath: "/workspace/src/routes/user-form.tsx",
		children: void 0,
		preloads: [
			"/assets/user-form-C7hxohNP.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/users": {
		filePath: "/workspace/src/routes/users.tsx",
		children: void 0,
		preloads: [
			"/assets/users-Cp75Gx7p.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/product/$id": {
		filePath: "/workspace/src/routes/product.$id.tsx",
		children: ["/product/$id/task/$taskId"],
		preloads: [
			"/assets/product._id-CCd-SVCs.js",
			"/assets/sortable-task-list-ClBh1pBS.js",
			"/assets/require-shop-B7rmFwzG.js",
			"/assets/ui-E61OhsJF.js"
		]
	},
	"/product/$id/task/$taskId": {
		filePath: "/workspace/src/routes/product.$id.task.$taskId.tsx",
		children: void 0,
		preloads: ["/assets/product._id.task._taskId-CXN3-rKu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
