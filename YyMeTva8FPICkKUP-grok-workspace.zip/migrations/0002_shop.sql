-- ForgeDesk local data (users.db / products.db / status.db equivalents)
-- Shared company tables — not scoped to a Grok identity.

create table if not exists shop_users (
  id           serial primary key,
  previewname  text not null,
  username     text not null unique,
  password     text not null,
  access       text not null check (access in ('full-access', 'editor', 'viewer'))
);

create table if not exists shop_sessions (
  token      text primary key,
  user_id    integer not null references shop_users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists shop_products (
  id         serial primary key,
  name       text not null,
  serial     text not null unique
);

create table if not exists shop_product_tasks (
  id                 serial primary key,
  product_id         integer not null references shop_products(id) on delete cascade,
  task_index         integer not null,
  name               text not null,
  description        text not null default '',
  assigned_username  text not null default '',
  unique (product_id, task_index)
);

create table if not exists shop_task_status (
  id                serial primary key,
  product_id        integer not null references shop_products(id) on delete cascade,
  task_id           integer not null references shop_product_tasks(id) on delete cascade,
  finished          boolean not null default false,
  completion_data   text not null default '',
  unique (product_id, task_id)
);

create index if not exists shop_sessions_user_id_idx on shop_sessions (user_id);
create index if not exists shop_product_tasks_product_idx on shop_product_tasks (product_id, task_index);
create index if not exists shop_task_status_product_idx on shop_task_status (product_id);

-- Seed accounts so the login screen is usable immediately.
insert into shop_users (previewname, username, password, access)
select 'Alex Chen', 'manager', 'manager', 'full-access'
where not exists (select 1 from shop_users where username = 'manager');

insert into shop_users (previewname, username, password, access)
select 'Sam Ortiz', 'editor', 'editor', 'editor'
where not exists (select 1 from shop_users where username = 'editor');

insert into shop_users (previewname, username, password, access)
select 'Riley Cho', 'viewer', 'viewer', 'viewer'
where not exists (select 1 from shop_users where username = 'viewer');

insert into shop_products (name, serial)
select 'Hydraulic Press HP-12', 'HP12-0042'
where not exists (select 1 from shop_products where serial = 'HP12-0042');

insert into shop_product_tasks (product_id, task_index, name, description, assigned_username)
select p.id, 1, 'Incoming inspection',
       'Check crate, serial plate, and housing for damage or missing parts.',
       'editor'
from shop_products p
where p.serial = 'HP12-0042'
  and not exists (
    select 1 from shop_product_tasks t
    where t.product_id = p.id and t.task_index = 1
  );

insert into shop_product_tasks (product_id, task_index, name, description, assigned_username)
select p.id, 2, 'Assembly check',
       'Verify ram alignment, hoses, and electrical harness before power-on.',
       'editor'
from shop_products p
where p.serial = 'HP12-0042'
  and not exists (
    select 1 from shop_product_tasks t
    where t.product_id = p.id and t.task_index = 2
  );

insert into shop_product_tasks (product_id, task_index, name, description, assigned_username)
select p.id, 3, 'Final QA',
       'Run pressure cycle, record results, and sign off for shipping.',
       'manager'
from shop_products p
where p.serial = 'HP12-0042'
  and not exists (
    select 1 from shop_product_tasks t
    where t.product_id = p.id and t.task_index = 3
  );

-- Status rows for every template task (unfinished by default).
insert into shop_task_status (product_id, task_id, finished, completion_data)
select t.product_id, t.id, false, ''
from shop_product_tasks t
where not exists (
  select 1 from shop_task_status s where s.task_id = t.id
);

-- Mark the first sample task finished so sequential flow is visible.
update shop_task_status s
set finished = true,
    completion_data = 'Crate intact. Serial plate matches HP12-0042.'
from shop_product_tasks t
join shop_products p on p.id = t.product_id
where s.task_id = t.id
  and p.serial = 'HP12-0042'
  and t.task_index = 1;
