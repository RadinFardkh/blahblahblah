import { Navigate } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useShop } from "@/lib/shop-provider";
import type { Access } from "@/lib/shop-types";

export function RequireShop({
  children,
  access,
}: {
  children: ReactNode;
  access?: Access[];
}) {
  const { user, ready } = useShop();
  if (!ready) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg text-sm text-muted">
        Loading…
      </div>
    );
  }
  if (!user) return <Navigate to="/" />;
  if (access && !access.includes(user.access)) return <Navigate to="/home" />;
  return <>{children}</>;
}
