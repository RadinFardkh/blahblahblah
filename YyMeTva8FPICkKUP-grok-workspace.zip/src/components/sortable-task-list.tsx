import { useRef, useState } from "react";
import { GripVertical } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProductTask } from "@/lib/shop-types";

export function SortableTaskList({
  tasks,
  onOpen,
  onReorder,
  showIndex,
  colorByStatus,
  draggable,
}: {
  tasks: ProductTask[];
  onOpen: (task: ProductTask) => void;
  onReorder?: (orderedIds: number[]) => void;
  showIndex?: boolean;
  colorByStatus?: boolean;
  draggable?: boolean;
}) {
  const [draggingId, setDraggingId] = useState<number | null>(null);
  const [overId, setOverId] = useState<number | null>(null);
  const dragIdRef = useRef<number | null>(null);
  const overIdRef = useRef<number | null>(null);

  if (tasks.length === 0) {
    return (
      <div className="flex min-h-32 items-center justify-center rounded-lg border border-dashed border-border bg-surface text-sm text-muted">
        No tasks yet
      </div>
    );
  }

  function finishDrag() {
    const fromId = dragIdRef.current;
    const toId = overIdRef.current;
    dragIdRef.current = null;
    overIdRef.current = null;
    setDraggingId(null);
    setOverId(null);
    if (fromId == null || toId == null || fromId === toId) return;
    const next = tasks.map((t) => t.id);
    const from = next.indexOf(fromId);
    const to = next.indexOf(toId);
    if (from < 0 || to < 0) return;
    next.splice(from, 1);
    next.splice(to, 0, fromId);
    onReorder?.(next);
  }

  return (
    <ul className="flex flex-col gap-2">
      {tasks.map((task) => {
        const isOver = overId === task.id && draggingId !== task.id;
        return (
          <li
            key={task.id}
            data-task-id={task.id}
            className={cn(
              "flex items-stretch overflow-hidden rounded-md border bg-panel",
              isOver ? "border-primary" : "border-border",
              draggingId === task.id && "opacity-70",
            )}
          >
            {draggable ? (
              <button
                type="button"
                aria-label="Drag to reorder"
                className="flex w-10 shrink-0 touch-none cursor-grab items-center justify-center border-r border-border text-subtle active:cursor-grabbing"
                onPointerDown={(event) => {
                  event.preventDefault();
                  event.currentTarget.setPointerCapture(event.pointerId);
                  dragIdRef.current = task.id;
                  overIdRef.current = task.id;
                  setDraggingId(task.id);
                  setOverId(task.id);
                }}
                onPointerMove={(event) => {
                  if (dragIdRef.current == null) return;
                  const el = document.elementFromPoint(event.clientX, event.clientY);
                  const row = el?.closest("[data-task-id]") as HTMLElement | null;
                  const id = row ? Number(row.dataset.taskId) : NaN;
                  if (!Number.isFinite(id)) return;
                  overIdRef.current = id;
                  setOverId(id);
                }}
                onPointerUp={finishDrag}
                onPointerCancel={finishDrag}
              >
                <GripVertical className="size-4" />
              </button>
            ) : null}
            <button
              type="button"
              onClick={() => onOpen(task)}
              className="flex min-h-12 flex-1 items-center px-3 py-2 text-left text-[15px]"
            >
              <span
                className={cn(
                  colorByStatus && task.finished ? "font-medium text-success" : "text-fg",
                )}
              >
                {showIndex ? `${task.index}. ${task.name}` : task.name}
              </span>
            </button>
          </li>
        );
      })}
    </ul>
  );
}
