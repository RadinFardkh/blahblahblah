import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";

export function Screen({
  title,
  onBack,
  footer,
  children,
  wide,
}: {
  title?: string;
  onBack?: () => void;
  footer?: ReactNode;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      {title || onBack ? (
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-border bg-panel px-4">
          {onBack ? (
            <button
              type="button"
              onClick={onBack}
              className="inline-flex h-9 min-w-16 items-center justify-center rounded-md border border-border bg-surface px-3 text-sm font-medium text-fg hover:bg-row"
            >
              Back
            </button>
          ) : null}
          {title ? <h1 className="text-[15px] font-semibold tracking-tight">{title}</h1> : null}
        </header>
      ) : null}
      <main className={cn("flex flex-1 flex-col overflow-auto p-4", wide ? "mx-auto w-full max-w-3xl" : "")}>
        {children}
      </main>
      {footer ? (
        <footer className="shrink-0 border-t border-border bg-panel px-4 py-3">{footer}</footer>
      ) : null}
    </div>
  );
}

export function Field({
  label,
  error,
  message,
  children,
}: {
  label: string;
  error?: boolean;
  message?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex w-full flex-col">
      <label className="mb-1.5 text-[13px] font-medium text-fg">{label}</label>
      {children}
      <p
        className={cn(
          "mt-1.5 min-h-5 text-xs leading-4",
          error && message ? "text-muted" : "text-transparent",
        )}
      >
        {message || "placeholder"}
      </p>
    </div>
  );
}

const controlClass =
  "h-11 w-full rounded-md border bg-panel px-3 text-[15px] text-fg outline-none transition-colors placeholder:text-subtle focus:border-primary";

export function TextBox({
  error,
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { error?: boolean }) {
  return (
    <input
      {...props}
      className={cn(controlClass, error ? "border-danger" : "border-border", className)}
    />
  );
}

export function AreaBox({
  error,
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement> & { error?: boolean }) {
  return (
    <textarea
      {...props}
      className={cn(
        "min-h-24 w-full resize-y rounded-md border bg-panel px-3 py-2 text-[15px] text-fg outline-none placeholder:text-subtle focus:border-primary",
        error ? "border-danger" : "border-border",
        className,
      )}
    />
  );
}

export function DropBox({
  error,
  className,
  children,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement> & { error?: boolean }) {
  return (
    <select
      {...props}
      className={cn(controlClass, error ? "border-danger" : "border-border", className)}
    >
      {children}
    </select>
  );
}

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
}) {
  return (
    <button
      {...props}
      className={cn(
        "inline-flex h-11 items-center justify-center rounded-md px-4 text-sm font-semibold transition-colors",
        variant === "primary" &&
          "bg-primary text-primary-fg hover:opacity-90 disabled:bg-disabled disabled:text-disabled-fg",
        variant === "secondary" &&
          "border border-border bg-panel text-fg hover:bg-row disabled:bg-row disabled:text-disabled-fg",
        variant === "ghost" && "text-muted hover:text-fg",
        className,
      )}
    />
  );
}

export function Popup({
  title,
  children,
  onClose,
}: {
  title: string;
  children?: ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-fg/40 p-4">
      <div
        role="dialog"
        aria-labelledby="popup-title"
        className="w-full max-w-sm rounded-xl border border-border bg-panel p-5 shadow-lg"
      >
        <h2 id="popup-title" className="text-base font-semibold">
          {title}
        </h2>
        {children ? <div className="mt-2 text-sm text-muted">{children}</div> : null}
        <div className="mt-5 flex justify-end">
          <Button type="button" onClick={onClose} className="min-w-24">
            OK
          </Button>
        </div>
      </div>
    </div>
  );
}

export function CheckPair({
  finished,
  onChange,
  disabled,
}: {
  finished: boolean;
  onChange: (finished: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex flex-wrap gap-6 py-1">
      <label className="inline-flex min-h-11 items-center gap-2 text-sm">
        <input
          type="checkbox"
          className="size-5 accent-success"
          checked={finished}
          disabled={disabled}
          onChange={() => onChange(true)}
        />
        Finished
      </label>
      <label className="inline-flex min-h-11 items-center gap-2 text-sm">
        <input
          type="checkbox"
          className="size-5 accent-primary"
          checked={!finished}
          disabled={disabled}
          onChange={() => onChange(false)}
        />
        Unfinished
      </label>
    </div>
  );
}
