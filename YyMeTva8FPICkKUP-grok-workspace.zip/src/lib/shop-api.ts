import { createServerFn } from "@tanstack/react-start";
import { shopAuth, shopSession } from "./shop-middleware";
import { ACCESS_LEVELS, type Access } from "./shop-types";

function asString(value: unknown, name: string): string {
  if (typeof value !== "string") throw new Error(`${name} is required`);
  return value;
}

function asNumber(value: unknown, name: string): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) {
    return Number(value);
  }
  throw new Error(`${name} is required`);
}

function asAccess(value: unknown): Access {
  const v = asString(value, "access");
  if (!(ACCESS_LEVELS as readonly string[]).includes(v)) {
    throw new Error("Access must be full-access, editor, or viewer");
  }
  return v as Access;
}

function asObject(data: unknown): Record<string, unknown> {
  if (!data || typeof data !== "object") throw new Error("Invalid payload");
  return data as Record<string, unknown>;
}

export const loginFn = createServerFn({ method: "POST" })
  .validator((data: unknown) => {
    const d = asObject(data);
    return {
      username: asString(d.username, "username"),
      password: asString(d.password, "password"),
    };
  })
  .handler(async ({ data }) => {
    const db = await import("./shop-db.server");
    const result = await db.loginWithPassword(data.username, data.password);
    if (!result) return { ok: false as const };
    return { ok: true as const, token: result.token, user: result.user };
  });

export const logoutFn = createServerFn({ method: "POST" })
  .middleware([shopSession])
  .handler(async ({ context }) => {
    const db = await import("./shop-db.server");
    await db.logoutToken(context.shopToken);
    return { ok: true };
  });

export const getMeFn = createServerFn({ method: "GET" })
  .middleware([shopSession])
  .handler(async ({ context }) => {
    return context.shopUser ?? null;
  });

export const listProductsFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .handler(async () => {
    const db = await import("./shop-db.server");
    return db.listProducts();
  });

export const getProductFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .validator((data: unknown) => ({ id: asNumber(asObject(data).id, "id") }))
  .handler(async ({ data }) => {
    const db = await import("./shop-db.server");
    return db.getProduct(data.id);
  });

export const saveProductFn = createServerFn({ method: "POST" })
  .middleware([shopAuth])
  .validator((data: unknown) => {
    const d = asObject(data);
    return {
      id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
      name: asString(d.name, "name").trim(),
      serial: asString(d.serial, "serial").trim(),
    };
  })
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    if (!data.name) throw new Error("Product name is required");
    if (!data.serial) throw new Error("Serial is required");
    if (data.id == null) return db.createProduct(data.name, data.serial);
    return db.updateProduct(data.id, data.name, data.serial);
  });

export const saveTaskFn = createServerFn({ method: "POST" })
  .middleware([shopAuth])
  .validator((data: unknown) => {
    const d = asObject(data);
    return {
      productId: asNumber(d.productId, "productId"),
      taskId: d.taskId == null || d.taskId === "" ? null : asNumber(d.taskId, "taskId"),
      name: asString(d.name, "name").trim(),
      description: asString(d.description, "description"),
      assignedUsername: asString(d.assignedUsername, "assignedUsername"),
    };
  })
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    if (!data.name) throw new Error("Task name is required");
    if (data.taskId == null) {
      return db.createTask({
        productId: data.productId,
        name: data.name,
        description: data.description,
        assignedUsername: data.assignedUsername,
      });
    }
    return db.updateTask({
      taskId: data.taskId,
      name: data.name,
      description: data.description,
      assignedUsername: data.assignedUsername,
    });
  });

export const reorderTasksFn = createServerFn({ method: "POST" })
  .middleware([shopAuth])
  .validator((data: unknown) => {
    const d = asObject(data);
    const orderedIds = d.orderedIds;
    if (!Array.isArray(orderedIds) || orderedIds.some((id) => typeof id !== "number")) {
      throw new Error("orderedIds is required");
    }
    return {
      productId: asNumber(d.productId, "productId"),
      orderedIds: orderedIds as number[],
    };
  })
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    await db.reorderTasks(data.productId, data.orderedIds);
    return db.getProduct(data.productId);
  });

export const canOpenTaskFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .validator((data: unknown) => ({
    taskId: asNumber(asObject(data).taskId, "taskId"),
  }))
  .handler(async ({ data }) => {
    const db = await import("./shop-db.server");
    const ok = await db.previousTasksFinished(data.taskId);
    return { ok };
  });

export const saveTaskStatusFn = createServerFn({ method: "POST" })
  .middleware([shopAuth])
  .validator((data: unknown) => {
    const d = asObject(data);
    return {
      taskId: asNumber(d.taskId, "taskId"),
      finished: Boolean(d.finished),
      completionData: asString(d.completionData, "completionData"),
    };
  })
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireEditor(context.shopUser);
    return db.updateTaskStatus(data);
  });

export const listUsersFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .handler(async ({ context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    return db.listUsers();
  });

export const listUserOptionsFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .handler(async () => {
    const db = await import("./shop-db.server");
    const users = await db.listUsers();
    return users.map((u) => ({
      username: u.username,
      previewname: u.previewname,
    }));
  });

export const getUserFn = createServerFn({ method: "GET" })
  .middleware([shopAuth])
  .validator((data: unknown) => ({ id: asNumber(asObject(data).id, "id") }))
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    return db.getUser(data.id);
  });

export const saveUserFn = createServerFn({ method: "POST" })
  .middleware([shopAuth])
  .validator((data: unknown) => {
    const d = asObject(data);
    return {
      id: d.id == null || d.id === "" ? null : asNumber(d.id, "id"),
      previewname: asString(d.previewname, "previewname").trim(),
      username: asString(d.username, "username").trim(),
      password: asString(d.password, "password"),
      access: asAccess(d.access),
    };
  })
  .handler(async ({ data, context }) => {
    const db = await import("./shop-db.server");
    db.requireFullAccess(context.shopUser);
    if (!data.previewname) throw new Error("Preview name is required");
    if (!data.username) throw new Error("Username is required");
    if (!data.password) throw new Error("Password is required");
    if (data.id == null) {
      return db.createUser({
        previewname: data.previewname,
        username: data.username,
        password: data.password,
        access: data.access,
      });
    }
    return db.updateUser(
      data.id,
      {
        previewname: data.previewname,
        username: data.username,
        password: data.password,
        access: data.access,
      },
      context.shopUser.id,
    );
  });
