import { getSql } from "@/lib/db";
import type { Access, ProductDetail, ProductSummary, ProductTask, ShopUser, ShopUserRecord } from "./shop-types";
import { ACCESS_LEVELS } from "./shop-types";

function asAccess(value: string): Access {
  if ((ACCESS_LEVELS as readonly string[]).includes(value)) return value as Access;
  return "viewer";
}

function asBool(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1;
}

type UserRow = {
  id: number;
  previewname: string;
  username: string;
  password: string;
  access: string;
};

function toUser(row: UserRow): ShopUser {
  return {
    id: row.id,
    previewname: row.previewname,
    username: row.username,
    access: asAccess(row.access),
  };
}

function toUserRecord(row: UserRow): ShopUserRecord {
  return { ...toUser(row), password: row.password };
}

export async function loadUserByToken(token: string): Promise<ShopUser | null> {
  const sql = await getSql();
  const rows = await sql<UserRow>`
    select u.id, u.previewname, u.username, u.password, u.access
    from shop_sessions s
    join shop_users u on u.id = s.user_id
    where s.token = ${token}
    limit 1
  `;
  return rows[0] ? toUser(rows[0]) : null;
}

export async function loginWithPassword(
  username: string,
  password: string,
): Promise<{ token: string; user: ShopUser } | null> {
  const sql = await getSql();
  const rows = await sql<UserRow>`
    select id, previewname, username, password, access
    from shop_users
    where username = ${username}
    limit 1
  `;
  const row = rows[0];
  if (!row || row.password !== password) return null;
  const token = crypto.randomUUID();
  await sql`insert into shop_sessions (token, user_id) values (${token}, ${row.id})`;
  return { token, user: toUser(row) };
}

export async function logoutToken(token: string | undefined) {
  if (!token) return;
  const sql = await getSql();
  await sql`delete from shop_sessions where token = ${token}`;
}

export async function listUsers(): Promise<ShopUserRecord[]> {
  const sql = await getSql();
  const rows = await sql<UserRow>`
    select id, previewname, username, password, access
    from shop_users
    order by id
  `;
  return rows.map(toUserRecord);
}

export async function getUser(id: number): Promise<ShopUserRecord | null> {
  const sql = await getSql();
  const rows = await sql<UserRow>`
    select id, previewname, username, password, access
    from shop_users where id = ${id} limit 1
  `;
  return rows[0] ? toUserRecord(rows[0]) : null;
}

export async function createUser(input: {
  previewname: string;
  username: string;
  password: string;
  access: Access;
}): Promise<ShopUserRecord> {
  const sql = await getSql();
  const taken = await sql<{ n: number }>`
    select count(*)::int as n from shop_users where username = ${input.username}
  `;
  if ((taken[0]?.n ?? 0) > 0) throw new Error("Username already exists");
  const rows = await sql<UserRow>`
    insert into shop_users (previewname, username, password, access)
    values (${input.previewname}, ${input.username}, ${input.password}, ${input.access})
    returning id, previewname, username, password, access
  `;
  return toUserRecord(rows[0]);
}

export async function updateUser(
  id: number,
  input: {
    previewname: string;
    username: string;
    password: string;
    access: Access;
  },
  actorId: number,
): Promise<ShopUserRecord> {
  const sql = await getSql();
  const current = await getUser(id);
  if (!current) throw new Error("User not found");

  const taken = await sql<{ n: number }>`
    select count(*)::int as n from shop_users
    where username = ${input.username} and id <> ${id}
  `;
  if ((taken[0]?.n ?? 0) > 0) throw new Error("Username already exists");

  if (current.access === "full-access" && input.access !== "full-access") {
    const remaining = await sql<{ n: number }>`
      select count(*)::int as n from shop_users
      where access = 'full-access' and id <> ${id}
    `;
    if ((remaining[0]?.n ?? 0) < 1) {
      throw new Error("At least one full-access user is required");
    }
    if (actorId === id) {
      throw new Error("You cannot remove your own full-access role");
    }
  }

  const rows = await sql<UserRow>`
    update shop_users
    set previewname = ${input.previewname},
        username = ${input.username},
        password = ${input.password},
        access = ${input.access}
    where id = ${id}
    returning id, previewname, username, password, access
  `;
  return toUserRecord(rows[0]);
}

export async function listProducts(): Promise<ProductSummary[]> {
  const sql = await getSql();
  return sql<ProductSummary>`
    select id, name, serial from shop_products order by id
  `;
}

type TaskRow = {
  id: number;
  product_id: number;
  task_index: number;
  name: string;
  description: string;
  assigned_username: string;
  finished: boolean | string | number | null;
  completion_data: string | null;
};

function toTask(row: TaskRow): ProductTask {
  return {
    id: row.id,
    productId: row.product_id,
    index: row.task_index,
    name: row.name,
    description: row.description,
    assignedUsername: row.assigned_username,
    finished: asBool(row.finished),
    completionData: row.completion_data ?? "",
  };
}

export async function getProduct(id: number): Promise<ProductDetail | null> {
  const sql = await getSql();
  const products = await sql<ProductSummary>`
    select id, name, serial from shop_products where id = ${id} limit 1
  `;
  const product = products[0];
  if (!product) return null;
  const tasks = await sql<TaskRow>`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.product_id = ${id}
    order by t.task_index
  `;
  return { ...product, tasks: tasks.map(toTask) };
}

async function ensureStatusRow(productId: number, taskId: number) {
  const sql = await getSql();
  await sql`
    insert into shop_task_status (product_id, task_id, finished, completion_data)
    values (${productId}, ${taskId}, false, '')
    on conflict (product_id, task_id) do nothing
  `;
}

export async function createProduct(name: string, serial: string): Promise<ProductDetail> {
  const sql = await getSql();
  const taken = await sql<{ n: number }>`
    select count(*)::int as n from shop_products where serial = ${serial}
  `;
  if ((taken[0]?.n ?? 0) > 0) throw new Error("Serial already exists");
  const rows = await sql<ProductSummary>`
    insert into shop_products (name, serial)
    values (${name}, ${serial})
    returning id, name, serial
  `;
  return { ...rows[0], tasks: [] };
}

export async function updateProduct(
  id: number,
  name: string,
  serial: string,
): Promise<ProductDetail> {
  const sql = await getSql();
  const taken = await sql<{ n: number }>`
    select count(*)::int as n from shop_products
    where serial = ${serial} and id <> ${id}
  `;
  if ((taken[0]?.n ?? 0) > 0) throw new Error("Serial already exists");
  await sql`
    update shop_products set name = ${name}, serial = ${serial} where id = ${id}
  `;
  const product = await getProduct(id);
  if (!product) throw new Error("Product not found");
  return product;
}

export async function createTask(input: {
  productId: number;
  name: string;
  description: string;
  assignedUsername: string;
}): Promise<ProductTask> {
  const sql = await getSql();
  const maxRows = await sql<{ m: number | null }>`
    select max(task_index)::int as m from shop_product_tasks where product_id = ${input.productId}
  `;
  const nextIndex = (maxRows[0]?.m ?? 0) + 1;
  const rows = await sql<{ id: number }>`
    insert into shop_product_tasks (product_id, task_index, name, description, assigned_username)
    values (${input.productId}, ${nextIndex}, ${input.name}, ${input.description}, ${input.assignedUsername})
    returning id
  `;
  const taskId = rows[0].id;
  await ensureStatusRow(input.productId, taskId);
  const product = await getProduct(input.productId);
  const task = product?.tasks.find((t) => t.id === taskId);
  if (!task) throw new Error("Task was not created");
  return task;
}

export async function updateTask(input: {
  taskId: number;
  name: string;
  description: string;
  assignedUsername: string;
}): Promise<ProductTask> {
  const sql = await getSql();
  await sql`
    update shop_product_tasks
    set name = ${input.name},
        description = ${input.description},
        assigned_username = ${input.assignedUsername}
    where id = ${input.taskId}
  `;
  const rows = await sql<TaskRow>`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.id = ${input.taskId}
    limit 1
  `;
  if (!rows[0]) throw new Error("Task not found");
  return toTask(rows[0]);
}

export async function reorderTasks(productId: number, orderedIds: number[]) {
  const sql = await getSql();
  for (let i = 0; i < orderedIds.length; i += 1) {
    const id = orderedIds[i];
    const index = i + 1;
    await sql`
      update shop_product_tasks
      set task_index = ${index}
      where id = ${id} and product_id = ${productId}
    `;
  }
}

export async function updateTaskStatus(input: {
  taskId: number;
  finished: boolean;
  completionData: string;
}): Promise<ProductTask> {
  const sql = await getSql();
  const found = await sql<{ product_id: number; task_index: number }>`
    select product_id, task_index from shop_product_tasks where id = ${input.taskId} limit 1
  `;
  const task = found[0];
  if (!task) throw new Error("Task not found");

  if (input.finished) {
    const blockers = await sql<{ n: number }>`
      select count(*)::int as n
      from shop_product_tasks t
      left join shop_task_status s on s.task_id = t.id
      where t.product_id = ${task.product_id}
        and t.task_index < ${task.task_index}
        and coalesce(s.finished, false) = false
    `;
    if ((blockers[0]?.n ?? 0) > 0) {
      throw new Error("Please finish the previous tasks");
    }
  }

  await ensureStatusRow(task.product_id, input.taskId);
  await sql`
    update shop_task_status
    set finished = ${input.finished},
        completion_data = ${input.completionData}
    where task_id = ${input.taskId}
  `;

  const rows = await sql<TaskRow>`
    select t.id, t.product_id, t.task_index, t.name, t.description, t.assigned_username,
           coalesce(s.finished, false) as finished,
           coalesce(s.completion_data, '') as completion_data
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.id = ${input.taskId}
    limit 1
  `;
  return toTask(rows[0]);
}

export async function previousTasksFinished(taskId: number): Promise<boolean> {
  const sql = await getSql();
  const found = await sql<{ product_id: number; task_index: number }>`
    select product_id, task_index from shop_product_tasks where id = ${taskId} limit 1
  `;
  const task = found[0];
  if (!task) return false;
  const blockers = await sql<{ n: number }>`
    select count(*)::int as n
    from shop_product_tasks t
    left join shop_task_status s on s.task_id = t.id
    where t.product_id = ${task.product_id}
      and t.task_index < ${task.task_index}
      and coalesce(s.finished, false) = false
  `;
  return (blockers[0]?.n ?? 0) === 0;
}

export function requireFullAccess(user: ShopUser) {
  if (user.access !== "full-access") throw new Error("Full-access only");
}

export function requireEditor(user: ShopUser) {
  if (user.access !== "full-access" && user.access !== "editor") {
    throw new Error("You do not have permission to edit this");
  }
}
