import { createMiddleware } from "@tanstack/react-start";
import { getStoredToken } from "./shop-session";
import type { ShopUser } from "./shop-types";

async function resolveUser(token: string | undefined): Promise<ShopUser | null> {
  if (!token) return null;
  const { loadUserByToken } = await import("./shop-db.server");
  return loadUserByToken(token);
}

/** Attaches shopUser (null if signed out) and the raw token. */
export const shopSession = createMiddleware({ type: "function" })
  .client(async ({ next }) => {
    return next({ sendContext: { shopToken: getStoredToken() ?? undefined } });
  })
  .server(async ({ next, context }) => {
    const shopToken = (context as { shopToken?: string }).shopToken;
    const shopUser = await resolveUser(shopToken);
    return next({ context: { shopUser, shopToken } });
  });

/** Requires a signed-in shop user. */
export const shopAuth = createMiddleware({ type: "function" })
  .client(async ({ next }) => {
    return next({ sendContext: { shopToken: getStoredToken() ?? undefined } });
  })
  .server(async ({ next, context }) => {
    const shopToken = (context as { shopToken?: string }).shopToken;
    const shopUser = await resolveUser(shopToken);
    if (!shopUser) {
      throw new Error("Not signed in");
    }
    return next({ context: { shopUser, shopToken } });
  });
