import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { getMeFn, loginFn, logoutFn } from "./shop-api";
import { clearStoredToken, setStoredToken } from "./shop-session";
import type { ShopUser } from "./shop-types";

type ShopContextValue = {
  user: ShopUser | null;
  ready: boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
};

const ShopContext = createContext<ShopContextValue | null>(null);

export function ShopProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<ShopUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getMeFn()
      .then((next) => {
        if (!cancelled) setUser(next);
      })
      .catch(() => {
        if (!cancelled) setUser(null);
      })
      .finally(() => {
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const value = useMemo<ShopContextValue>(
    () => ({
      user,
      ready,
      login: async (username, password) => {
        const result = await loginFn({ data: { username, password } });
        if (!result.ok) return false;
        setStoredToken(result.token);
        setUser(result.user);
        return true;
      },
      logout: async () => {
        try {
          await logoutFn();
        } catch {
          // still clear local session
        }
        clearStoredToken();
        setUser(null);
      },
    }),
    [user, ready],
  );

  return <ShopContext.Provider value={value}>{children}</ShopContext.Provider>;
}

export function useShop() {
  const ctx = useContext(ShopContext);
  if (!ctx) throw new Error("useShop must be used inside ShopProvider");
  return ctx;
}
