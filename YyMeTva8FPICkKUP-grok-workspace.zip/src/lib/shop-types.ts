export const ACCESS_LEVELS = ["full-access", "editor", "viewer"] as const;
export type Access = (typeof ACCESS_LEVELS)[number];

export type ShopUser = {
  id: number;
  previewname: string;
  username: string;
  access: Access;
};

export type ShopUserRecord = ShopUser & { password: string };

export type ProductSummary = {
  id: number;
  name: string;
  serial: string;
};

export type ProductTask = {
  id: number;
  productId: number;
  index: number;
  name: string;
  description: string;
  assignedUsername: string;
  finished: boolean;
  completionData: string;
};

export type ProductDetail = ProductSummary & {
  tasks: ProductTask[];
};
