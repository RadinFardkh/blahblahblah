import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { SortableTaskList } from "@/components/sortable-task-list";
import { Button, Field, Screen, TextBox } from "@/components/ui";
import { getProductFn, reorderTasksFn, saveProductFn } from "@/lib/shop-api";
import type { ProductTask } from "@/lib/shop-types";

type Search = { id?: number };

export const Route = createFileRoute("/assign-product")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    id: typeof s.id === "number" ? s.id : typeof s.id === "string" && s.id ? Number(s.id) : undefined,
  }),
  component: AssignProductRoute,
});

function AssignProductRoute() {
  return (
    <RequireShop access={["full-access"]}>
      <AssignProductPage />
    </RequireShop>
  );
}

function AssignProductPage() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [serial, setSerial] = useState("");
  const [productId, setProductId] = useState<number | null>(id ?? null);
  const [tasks, setTasks] = useState<ProductTask[]>([]);
  const [emptyName, setEmptyName] = useState(false);
  const [emptySerial, setEmptySerial] = useState(false);
  const [serialError, setSerialError] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (id == null || Number.isNaN(id)) return;
    let cancelled = false;
    getProductFn({ data: { id } }).then((product) => {
      if (cancelled || !product) return;
      setName(product.name);
      setSerial(product.serial);
      setProductId(product.id);
      setTasks(product.tasks);
    });
    return () => {
      cancelled = true;
    };
  }, [id]);

  function validateFields() {
    const nameEmpty = name.trim().length === 0;
    const serialEmpty = serial.trim().length === 0;
    setEmptyName(nameEmpty);
    setEmptySerial(serialEmpty);
    setSerialError(undefined);
    return !nameEmpty && !serialEmpty;
  }

  async function persistProduct() {
    if (!validateFields()) return null;
    setBusy(true);
    try {
      const product = await saveProductFn({
        data: { id: productId, name: name.trim(), serial: serial.trim() },
      });
      setProductId(product.id);
      setTasks(product.tasks);
      return product;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not save product";
      setSerialError(message);
      return null;
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen
      title={productId ? "Edit product" : "Assign product"}
      onBack={() => navigate({ to: "/home" })}
      wide
      footer={
        <div className="mx-auto flex w-full max-w-3xl justify-end">
          <Button
            type="button"
            disabled={busy}
            onClick={async () => {
              const product = await persistProduct();
              if (product) navigate({ to: "/home" });
            }}
            className="min-w-28"
          >
            Save
          </Button>
        </div>
      }
    >
      <div className="mx-auto flex w-full max-w-md flex-col pt-4">
        <Field label="Product Name" error={emptyName} message={emptyName ? "Required" : undefined}>
          <TextBox
            value={name}
            error={emptyName}
            onChange={(e) => {
              setName(e.target.value);
              setEmptyName(false);
            }}
          />
        </Field>
        <Field
          label="Serial"
          error={emptySerial || Boolean(serialError)}
          message={emptySerial ? "Required" : serialError}
        >
          <TextBox
            value={serial}
            error={emptySerial || Boolean(serialError)}
            onChange={(e) => {
              setSerial(e.target.value);
              setEmptySerial(false);
              setSerialError(undefined);
            }}
          />
        </Field>

        <p className="mb-2 text-[13px] font-medium">Tasks</p>
        <SortableTaskList
          tasks={tasks}
          draggable
          onOpen={(task) => {
            if (!productId) return;
            navigate({
              to: "/assign-task",
              search: { productId, taskId: task.id },
            });
          }}
          onReorder={async (orderedIds) => {
            if (!productId) return;
            const next = await reorderTasksFn({ data: { productId, orderedIds } });
            if (next) setTasks(next.tasks);
          }}
        />
        <Button
          type="button"
          variant="secondary"
          className="mt-3"
          disabled={busy}
          onClick={async () => {
            const product = await persistProduct();
            if (!product) return;
            navigate({
              to: "/assign-task",
              search: { productId: product.id },
            });
          }}
        >
          Add
        </Button>
      </div>
    </Screen>
  );
}
