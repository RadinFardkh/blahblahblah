import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { AreaBox, Button, DropBox, Field, Screen, TextBox } from "@/components/ui";
import { getProductFn, listUserOptionsFn, saveTaskFn } from "@/lib/shop-api";

type Search = { productId?: number; taskId?: number };

export const Route = createFileRoute("/assign-task")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    productId:
      typeof s.productId === "number"
        ? s.productId
        : typeof s.productId === "string" && s.productId
          ? Number(s.productId)
          : undefined,
    taskId:
      typeof s.taskId === "number"
        ? s.taskId
        : typeof s.taskId === "string" && s.taskId
          ? Number(s.taskId)
          : undefined,
  }),
  component: AssignTaskRoute,
});

function AssignTaskRoute() {
  return (
    <RequireShop access={["full-access"]}>
      <AssignTaskPage />
    </RequireShop>
  );
}

function AssignTaskPage() {
  const { productId, taskId } = Route.useSearch();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [assigned, setAssigned] = useState("");
  const [users, setUsers] = useState<{ username: string; previewname: string }[]>([]);
  const [emptyName, setEmptyName] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    listUserOptionsFn().then(setUsers);
  }, []);

  useEffect(() => {
    if (productId == null || taskId == null) return;
    let cancelled = false;
    getProductFn({ data: { id: productId } }).then((product) => {
      if (cancelled || !product) return;
      const task = product.tasks.find((t) => t.id === taskId);
      if (!task) return;
      setName(task.name);
      setDescription(task.description);
      setAssigned(task.assignedUsername);
    });
    return () => {
      cancelled = true;
    };
  }, [productId, taskId]);

  if (productId == null) {
    return (
      <Screen title="Task" onBack={() => navigate({ to: "/assign-product" })}>
        <p className="text-sm text-muted">Missing product.</p>
      </Screen>
    );
  }

  return (
    <Screen
      title={taskId ? "Edit task" : "Add task"}
      onBack={() => navigate({ to: "/assign-product", search: { id: productId } })}
      wide
      footer={
        <div className="mx-auto flex w-full max-w-3xl justify-end">
          <Button
            type="button"
            disabled={busy}
            className="min-w-28"
            onClick={async () => {
              if (!name.trim()) {
                setEmptyName(true);
                return;
              }
              setBusy(true);
              setError(undefined);
              try {
                await saveTaskFn({
                  data: {
                    productId,
                    taskId: taskId ?? null,
                    name: name.trim(),
                    description,
                    assignedUsername: assigned,
                  },
                });
                navigate({ to: "/assign-product", search: { id: productId } });
              } catch (err) {
                setError(err instanceof Error ? err.message : "Could not save task");
              } finally {
                setBusy(false);
              }
            }}
          >
            Save
          </Button>
        </div>
      }
    >
      <div className="mx-auto flex w-full max-w-md flex-col pt-4">
        <Field label="Task Name" error={emptyName} message={emptyName ? "Required" : undefined}>
          <TextBox
            value={name}
            error={emptyName}
            onChange={(e) => {
              setName(e.target.value);
              setEmptyName(false);
            }}
          />
        </Field>
        <Field label="Description:">
          <AreaBox value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <Field label="Assigned user">
          <DropBox value={assigned} onChange={(e) => setAssigned(e.target.value)}>
            <option value="">Unassigned</option>
            {users.map((u) => (
              <option key={u.username} value={u.username}>
                {u.previewname} ({u.username})
              </option>
            ))}
          </DropBox>
        </Field>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
      </div>
    </Screen>
  );
}
