import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { Button } from "@/components/ui";
import { listProductsFn } from "@/lib/shop-api";
import { useShop } from "@/lib/shop-provider";
import type { ProductSummary } from "@/lib/shop-types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/home")({ component: HomeRoute });

function HomeRoute() {
  return (
    <RequireShop>
      <HomePage />
    </RequireShop>
  );
}

function HomePage() {
  const { user, logout } = useShop();
  const navigate = useNavigate();
  const [products, setProducts] = useState<ProductSummary[] | null>(null);
  const isManager = user?.access === "full-access";

  useEffect(() => {
    let cancelled = false;
    listProductsFn().then((rows) => {
      if (!cancelled) setProducts(rows);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <div className="grid shrink-0 grid-cols-2 gap-3 p-4">
        <Button
          type="button"
          disabled={!isManager}
          onClick={() => navigate({ to: "/assign-product" })}
          className="h-12"
        >
          Assign product
        </Button>
        <Button
          type="button"
          disabled={!isManager}
          onClick={() => navigate({ to: "/users" })}
          className="h-12"
        >
          Configure users
        </Button>
      </div>

      <div className="mx-4 mb-4 flex min-h-0 flex-1 flex-col overflow-hidden rounded-lg border border-border bg-panel">
        {products == null ? (
          <p className="p-4 text-sm text-muted">Loading products…</p>
        ) : products.length === 0 ? (
          <p className="p-6 text-sm text-muted">No products yet.</p>
        ) : (
          <ul className="flex-1 overflow-y-auto">
            {products.map((product, index) => (
              <li key={product.id} className={cn(index > 0 && "border-t border-border")}>
                <button
                  type="button"
                  onClick={() =>
                    navigate({ to: "/product/$id", params: { id: String(product.id) } })
                  }
                  className="flex w-full flex-col items-start gap-0.5 px-4 py-3.5 text-left hover:bg-row"
                >
                  <span className="text-[15px] font-medium">{product.name}</span>
                  <span className="font-mono text-xs text-muted">{product.serial}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <footer className="flex shrink-0 items-center justify-between gap-3 border-t border-border bg-panel px-4 py-3 text-sm">
        <span className="text-muted">
          Status: <span className="font-medium text-fg">{user?.access}</span>
        </span>
        <span className="flex items-center gap-3">
          <span className="font-medium">{user?.previewname}</span>
          <button
            type="button"
            onClick={async () => {
              await logout();
              navigate({ to: "/" });
            }}
            className="text-xs text-muted underline-offset-2 hover:text-fg hover:underline"
          >
            Log out
          </button>
        </span>
      </footer>
    </div>
  );
}
