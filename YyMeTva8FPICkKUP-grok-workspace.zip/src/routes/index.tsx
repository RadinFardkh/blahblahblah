import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Button, Field, TextBox } from "@/components/ui";
import { useShop } from "@/lib/shop-provider";

export const Route = createFileRoute("/")({ component: LoginPage });

function LoginPage() {
  const { user, ready, login } = useShop();
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [emptyUser, setEmptyUser] = useState(false);
  const [emptyPass, setEmptyPass] = useState(false);
  const [incorrect, setIncorrect] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (ready && user) navigate({ to: "/home" });
  }, [ready, user, navigate]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    const userEmpty = username.trim().length === 0;
    const passEmpty = password.length === 0;
    setEmptyUser(userEmpty);
    setEmptyPass(passEmpty);
    setIncorrect(false);
    if (userEmpty || passEmpty) return;
    setBusy(true);
    try {
      const ok = await login(username.trim(), password);
      if (!ok) {
        setIncorrect(true);
        return;
      }
      navigate({ to: "/home" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-dvh flex-col bg-bg text-fg">
      <form onSubmit={onSubmit} className="flex flex-1 flex-col">
        <div className="flex flex-1 flex-col items-center justify-center px-6">
          <div className="w-[220px]">
            <Field
              label="Username:"
              error={emptyUser || incorrect}
              message={incorrect ? "Incorrect Username/Password" : undefined}
            >
              <TextBox
                name="username"
                autoComplete="username"
                value={username}
                error={emptyUser || incorrect}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setEmptyUser(false);
                  setIncorrect(false);
                }}
              />
            </Field>
            <Field
              label="Password:"
              error={emptyPass || incorrect}
              message={incorrect ? "Incorrect Username/Password" : undefined}
            >
              <TextBox
                name="password"
                type="password"
                autoComplete="current-password"
                value={password}
                error={emptyPass || incorrect}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setEmptyPass(false);
                  setIncorrect(false);
                }}
              />
            </Field>
          </div>
        </div>
        <div className="flex flex-col items-center gap-3 pb-10">
          <Button type="submit" disabled={busy} className="min-w-32">
            {busy ? "Checking…" : "Login"}
          </Button>
          <p className="max-w-xs text-center text-[11px] leading-4 text-subtle">
            Local demo: manager / manager · editor / editor · viewer / viewer
          </p>
        </div>
      </form>
    </div>
  );
}
