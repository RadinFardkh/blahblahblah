import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { AreaBox, Button, CheckPair, Field, Screen } from "@/components/ui";
import { getProductFn, saveTaskStatusFn } from "@/lib/shop-api";
import { useShop } from "@/lib/shop-provider";
import type { ProductTask } from "@/lib/shop-types";

export const Route = createFileRoute("/product/$id/task/$taskId")({
  component: TaskStatusRoute,
});

function TaskStatusRoute() {
  return (
    <RequireShop>
      <TaskStatusPage />
    </RequireShop>
  );
}

function TaskStatusPage() {
  const { id, taskId } = Route.useParams();
  const productId = Number(id);
  const numericTaskId = Number(taskId);
  const navigate = useNavigate();
  const { user } = useShop();
  const [task, setTask] = useState<ProductTask | null>(null);
  const [assignedLabel, setAssignedLabel] = useState("");
  const [finished, setFinished] = useState(false);
  const [completion, setCompletion] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>();
  const canEdit = user?.access === "full-access" || user?.access === "editor";

  useEffect(() => {
    getProductFn({ data: { id: productId } }).then((product) => {
      const found = product?.tasks.find((t) => t.id === numericTaskId);
      if (!found) return;
      setTask(found);
      setFinished(found.finished);
      setCompletion(found.completionData);
      setAssignedLabel(found.assignedUsername || "Unassigned");
    });
  }, [productId, numericTaskId]);

  return (
    <Screen
      title="Task"
      onBack={() => navigate({ to: "/product/$id", params: { id: String(productId) } })}
      wide
      footer={
        canEdit ? (
          <div className="mx-auto flex w-full max-w-3xl justify-end">
            <Button
              type="button"
              disabled={busy}
              className="min-w-28"
              onClick={async () => {
                setBusy(true);
                setError(undefined);
                try {
                  await saveTaskStatusFn({
                    data: {
                      taskId: numericTaskId,
                      finished,
                      completionData: completion,
                    },
                  });
                  navigate({ to: "/product/$id", params: { id: String(productId) } });
                } catch (err) {
                  setError(err instanceof Error ? err.message : "Could not save");
                } finally {
                  setBusy(false);
                }
              }}
            >
              Save
            </Button>
          </div>
        ) : null
      }
    >
      {!task ? (
        <p className="text-sm text-muted">Loading…</p>
      ) : (
        <div className="mx-auto flex w-full max-w-md flex-col gap-5 pt-4">
          <div>
            <p className="text-[13px] font-medium text-muted">Task name</p>
            <p className="mt-1 text-lg font-semibold">{task.name}</p>
          </div>
          <div>
            <p className="text-[13px] font-medium text-muted">Assigned to</p>
            <p className="mt-1 text-[15px]">{assignedLabel}</p>
          </div>
          <div>
            <p className="mb-1 text-[13px] font-medium">Status</p>
            <CheckPair finished={finished} onChange={setFinished} disabled={!canEdit} />
          </div>
          <Field label="Completion Data">
            <AreaBox
              value={completion}
              onChange={(e) => setCompletion(e.target.value)}
              disabled={!canEdit}
              placeholder="Optional notes"
            />
          </Field>
          {error ? <p className="text-sm text-danger">{error}</p> : null}
        </div>
      )}
    </Screen>
  );
}
