import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { SortableTaskList } from "@/components/sortable-task-list";
import { Button, Popup, Screen } from "@/components/ui";
import { canOpenTaskFn, getProductFn } from "@/lib/shop-api";
import { useShop } from "@/lib/shop-provider";
import type { ProductDetail } from "@/lib/shop-types";

export const Route = createFileRoute("/product/$id")({ component: ProductRoute });

function ProductRoute() {
  return (
    <RequireShop>
      <ProductPage />
    </RequireShop>
  );
}

function ProductPage() {
  const { id } = Route.useParams();
  const productId = Number(id);
  const navigate = useNavigate();
  const { user } = useShop();
  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [warning, setWarning] = useState(false);

  useEffect(() => {
    getProductFn({ data: { id: productId } }).then(setProduct);
  }, [productId]);

  return (
    <Screen title="Product" onBack={() => navigate({ to: "/home" })} wide>
      {!product ? (
        <p className="text-sm text-muted">Loading…</p>
      ) : (
        <div className="mx-auto flex w-full max-w-md flex-col gap-4 pt-2">
          <div>
            <p className="text-[13px] font-medium text-muted">Product Name</p>
            <p className="mt-1 text-lg font-semibold">{product.name}</p>
          </div>
          <div>
            <p className="text-[13px] font-medium text-muted">Serial</p>
            <p className="mt-1 font-mono text-[15px]">{product.serial}</p>
          </div>
          <div>
            <p className="mb-2 text-[13px] font-medium">Tasks</p>
            <SortableTaskList
              tasks={product.tasks}
              showIndex
              colorByStatus
              onOpen={async (task) => {
                const result = await canOpenTaskFn({ data: { taskId: task.id } });
                if (!result.ok) {
                  setWarning(true);
                  return;
                }
                navigate({
                  to: "/product/$id/task/$taskId",
                  params: { id: String(product.id), taskId: String(task.id) },
                });
              }}
            />
          </div>
          {user?.access === "full-access" ? (
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate({ to: "/assign-product", search: { id: product.id } })}
            >
              Edit product
            </Button>
          ) : null}
        </div>
      )}
      {warning ? (
        <Popup title="Please finish the previous tasks" onClose={() => setWarning(false)} />
      ) : null}
    </Screen>
  );
}
