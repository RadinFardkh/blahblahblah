import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { Button, DropBox, Field, Screen, TextBox } from "@/components/ui";
import { ACCESS_LEVELS, type Access } from "@/lib/shop-types";
import { getUserFn, saveUserFn } from "@/lib/shop-api";

type Search = { id?: number };

export const Route = createFileRoute("/user-form")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    id: typeof s.id === "number" ? s.id : typeof s.id === "string" && s.id ? Number(s.id) : undefined,
  }),
  component: UserFormRoute,
});

function UserFormRoute() {
  return (
    <RequireShop access={["full-access"]}>
      <UserFormPage />
    </RequireShop>
  );
}

function UserFormPage() {
  const { id } = Route.useSearch();
  const navigate = useNavigate();
  const [previewname, setPreviewname] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [access, setAccess] = useState<Access | "">("");
  const [empty, setEmpty] = useState({ previewname: false, username: false, password: false, access: false });
  const [error, setError] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (id == null) return;
    getUserFn({ data: { id } }).then((user) => {
      if (!user) return;
      setPreviewname(user.previewname);
      setUsername(user.username);
      setPassword(user.password);
      setAccess(user.access);
    });
  }, [id]);

  return (
    <Screen
      title={id ? "Edit user" : "New User"}
      onBack={() => navigate({ to: "/users" })}
      wide
      footer={
        <div className="mx-auto flex w-full max-w-3xl justify-end">
          <Button
            type="button"
            disabled={busy}
            className="min-w-28"
            onClick={async () => {
              const nextEmpty = {
                previewname: previewname.trim().length === 0,
                username: username.trim().length === 0,
                password: password.length === 0,
                access: access === "",
              };
              setEmpty(nextEmpty);
              setError(undefined);
              if (Object.values(nextEmpty).some(Boolean)) return;
              setBusy(true);
              try {
                await saveUserFn({
                  data: {
                    id: id ?? null,
                    previewname: previewname.trim(),
                    username: username.trim(),
                    password,
                    access: access as Access,
                  },
                });
                navigate({ to: "/users" });
              } catch (err) {
                setError(err instanceof Error ? err.message : "Could not save user");
              } finally {
                setBusy(false);
              }
            }}
          >
            Save
          </Button>
        </div>
      }
    >
      <div className="mx-auto flex w-full max-w-md flex-col pt-4">
        <Field
          label="Preview name"
          error={empty.previewname}
          message={empty.previewname ? "Required" : undefined}
        >
          <TextBox
            value={previewname}
            error={empty.previewname}
            onChange={(e) => {
              setPreviewname(e.target.value);
              setEmpty((s) => ({ ...s, previewname: false }));
            }}
          />
        </Field>
        <Field
          label="Username"
          error={empty.username}
          message={empty.username ? "Required" : undefined}
        >
          <TextBox
            value={username}
            error={empty.username}
            onChange={(e) => {
              setUsername(e.target.value);
              setEmpty((s) => ({ ...s, username: false }));
            }}
          />
        </Field>
        <Field
          label="Password"
          error={empty.password}
          message={empty.password ? "Required" : undefined}
        >
          <TextBox
            value={password}
            error={empty.password}
            onChange={(e) => {
              setPassword(e.target.value);
              setEmpty((s) => ({ ...s, password: false }));
            }}
          />
        </Field>
        <Field
          label="Access"
          error={empty.access}
          message={empty.access ? "Required" : undefined}
        >
          <DropBox
            value={access}
            error={empty.access}
            onChange={(e) => {
              setAccess(e.target.value as Access | "");
              setEmpty((s) => ({ ...s, access: false }));
            }}
          >
            <option value="">{id ? "" : "Select access"}</option>
            {ACCESS_LEVELS.map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            ))}
          </DropBox>
        </Field>
        {error ? <p className="text-sm text-danger">{error}</p> : null}
      </div>
    </Screen>
  );
}
