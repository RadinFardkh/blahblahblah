import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RequireShop } from "@/components/require-shop";
import { Button, Screen } from "@/components/ui";
import { listUsersFn } from "@/lib/shop-api";
import type { ShopUserRecord } from "@/lib/shop-types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/users")({ component: UsersRoute });

function UsersRoute() {
  return (
    <RequireShop access={["full-access"]}>
      <UsersPage />
    </RequireShop>
  );
}

function UsersPage() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<ShopUserRecord[] | null>(null);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  useEffect(() => {
    listUsersFn().then(setRows);
  }, []);

  return (
    <Screen title="Configure users" onBack={() => navigate({ to: "/home" })} wide>
      <div className="overflow-x-auto rounded-lg border border-border bg-panel">
        <table className="w-full min-w-[28rem] text-left text-sm">
          <thead className="border-b border-border bg-surface text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-3 py-2.5 font-medium">Preview name</th>
              <th className="px-3 py-2.5 font-medium">Username</th>
              <th className="px-3 py-2.5 font-medium">Access</th>
            </tr>
          </thead>
          <tbody>
            {(rows ?? []).map((row) => (
              <tr
                key={row.id}
                onClick={() => setSelectedId(row.id)}
                onDoubleClick={() => navigate({ to: "/user-form", search: { id: row.id } })}
                className={cn(
                  "cursor-pointer border-t border-border",
                  selectedId === row.id ? "bg-row-active" : "hover:bg-row",
                )}
              >
                <td className="px-3 py-3">{row.previewname}</td>
                <td className="px-3 py-3 font-mono text-[13px]">{row.username}</td>
                <td className="px-3 py-3">{row.access}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows && rows.length === 0 ? (
          <p className="px-3 py-6 text-sm text-muted">No users.</p>
        ) : null}
      </div>
      <div className="mt-4 flex flex-wrap gap-3">
        <Button
          type="button"
          variant="secondary"
          disabled={selectedId == null}
          onClick={() => {
            if (selectedId == null) return;
            navigate({ to: "/user-form", search: { id: selectedId } });
          }}
          className="min-w-28"
        >
          Edit
        </Button>
        <Button type="button" onClick={() => navigate({ to: "/user-form" })} className="min-w-28">
          New User
        </Button>
      </div>
    </Screen>
  );
}
